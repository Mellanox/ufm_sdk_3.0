#
# SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

from __future__ import annotations

import typing

if typing.TYPE_CHECKING:
    from pythoncm.cluster import Cluster


class CommitResult:
    ERROR = -1
    WARNING = 0
    VALIDATE_NOT_ACTIVE = 11

    """
    Class containing the result of committing any entity.
    """

    def __init__(self, cluster: Cluster, **kwargs):
        from pythoncm.entity.validation import Validation

        self.cluster = cluster
        self.new_key: int = kwargs.get('newKey', 0)
        self.success: bool = kwargs.get('success', False)
        self.task_id: int = kwargs.get('taskId', 0)
        self.validation = [Validation(self.cluster, it) for it in kwargs.get('validation', [])]
        if 'errormessage' in kwargs:
            self.add([kwargs['errormessage']])

    def add(self, errors, kind=ERROR):
        from pythoncm.entity.validation import Validation

        for error in errors:
            validation = Validation(self.cluster)
            validation.msg = error
            validation.warning = kind
            self.validation.append(validation)

    @property
    def good(self) -> bool:
        """
        True if commit did not have any errors.
        """
        return (self.new_key > 0) or self.success

    @property
    def not_active(self) -> bool:
        """
        True if head node was not active yet.
        """
        return any(it.code == self.VALIDATE_NOT_ACTIVE for it in self.validation)

    def wait_for_task(self, timeout: int | float | None = None) -> bool | None:
        """
        Wait for back ground task, if any, to be completed.
        """
        if self.task_id == 0:
            return None
        return self.cluster.background_task_manager.wait(self.task_id, timeout)

    def __repr__(self):
        """
        Return all validation warnings and errors.
        """
        return '\n'.join([it.msg for it in self.validation])
