#
# SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

from __future__ import annotations

import os
import pwd
import typing

import pythoncm.entity.metadata.devicestatus
import pythoncm.entity.metadata.poweroperation
from pythoncm.entity import BlockingOperation
from pythoncm.entity import BurnStatus
from pythoncm.entity import DrainResult
from pythoncm.entity import ExternalOperationResult
from pythoncm.entity import FirmwareInfo
from pythoncm.entity import NetworkConnection
from pythoncm.entity import Package
from pythoncm.entity import PingResult
from pythoncm.entity import PowerOperation
from pythoncm.entity import PowerOperationHistory
from pythoncm.entity import ProgramRunnerInput
from pythoncm.entity import Route
from pythoncm.entity import SysInfoCollector
from pythoncm.entity import VersionInfo
from pythoncm.entity.cloudnode import CloudNode
from pythoncm.entity.devicestatus import DeviceStatus
from pythoncm.entity.node import Node
from pythoncm.entity.programrunnerstatus import ProgramRunnerStatus
from pythoncm.entity_converter import EntityConverter

if typing.TYPE_CHECKING:
    from pythoncm.cluster import Cluster


class Parallel:
    """
    Wrapper class around all parallel RPC
    """

    def __init__(self, cluster: Cluster):
        self.cluster = cluster

    def device_status(self, devices):
        """
        Get the device status for one or more devices.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmstatus',
            call='getStatusForDevices',
            args=[self.cluster._entities_to_keys(devices)],
        )
        if code:
            raise OSError(out)
        return [
            DeviceStatus(self.cluster, it, parent=self.cluster.get_by_key(it.get('refDeviceUniqueKey', 0)))
            for it in out
            if it is not None
        ]

    def _power_operation(
        self,
        devices,
        operation,
        force=False,
        wait=False,
        timeout: int | float | None = None,
    ) -> bool:
        power_operation = PowerOperation()
        power_operation.devices = self.cluster._entities_to_keys(devices)
        power_operation.sessionId = self.cluster.session_id
        power_operation.force = force
        power_operation.operation = operation
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='powerOperation',
            args=[power_operation.to_dict()],
        )
        if code:
            raise OSError(out)
        count = out.get('count', 0)
        if count == 0:
            return False
        elif wait:
            index = out.get('index', 0)
            return self.cluster.power_operation_manager.wait(
                devices=power_operation.devices,
                index=index,
                count=count,
                timeout=timeout,
            )
        return True

    def power_status(self, devices, force=False, wait=True, timeout: int | float | None = None):
        """
        Get the power status for one or more devices.

        force: include closed devices
        wait: wait for completion
        """
        return self._power_operation(
            operation=pythoncm.entity.metadata.poweroperation.PowerOperation.Operation.STATUS,
            devices=devices,
            force=force,
            wait=wait,
            timeout=timeout,
        )

    def power_on(self, devices, force=False, wait=False, timeout: int | float | None = None):
        """
        Power on for one or more devices.

        force: include closed devices
        wait: wait for completion
        """
        return self._power_operation(
            operation=pythoncm.entity.metadata.poweroperation.PowerOperation.Operation.ON,
            devices=devices,
            force=force,
            wait=wait,
            timeout=timeout,
        )

    def power_off(self, devices, force=False, wait=False, timeout: int | float | None = None):
        """
        Power off for one or more devices.

        force: include closed devices
        wait: wait for completion
        """
        return self._power_operation(
            operation=pythoncm.entity.metadata.poweroperation.PowerOperation.Operation.OFF,
            devices=devices,
            force=force,
            wait=wait,
            timeout=timeout,
        )

    def power_reset(self, devices, force=False, wait=False, timeout: int | float | None = None):
        """
        Power reset for one or more devices.

        force: include closed devices
        wait: wait for completion
        """
        return self._power_operation(
            operation=pythoncm.entity.metadata.poweroperation.PowerOperation.Operation.RESET,
            devices=devices,
            force=force,
            wait=wait,
            timeout=timeout,
        )

    def open(self, devices, message=None):
        """
        Open for one or more devices.

        message: update the current status user message
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmstatus',
            call='open',
            args=[
                self.cluster._entities_to_keys(devices),
                '' if message is None else message,
                False if message is None else True,
            ],
        )
        if code:
            raise OSError(out)
        return out

    def close(self, devices, message=None):
        """
        Close for one or more devices.

        message: update the current status user message
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmstatus',
            call='close',
            args=[
                self.cluster._entities_to_keys(devices),
                '' if message is None else message,
                False if message is None else True,
            ],
        )
        if code:
            raise OSError(out)
        return out

    def mute(self, devices, message=None):
        """
        Mute for one or more devices, no more monitorring actions will be triggered

        message: update the current status user message
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmstatus',
            call='mute',
            args=[
                self.cluster._entities_to_keys(devices),
                '' if message is None else message,
                False if message is None else True,
            ],
        )
        if code:
            raise OSError(out)
        return out

    def unmute(self, devices, message=None):
        """
        Unmute for one or more devices.

        message: update the current status user message
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmstatus',
            call='unmute',
            args=[
                self.cluster._entities_to_keys(devices),
                '' if message is None else message,
                False if message is None else True,
            ],
        )
        if code:
            raise OSError(out)
        return out

    def restart_required(self, devices, reasons=None):
        """
        Set restart required for one or more devices.

        reasons: list of reasons, or single reason, restart is required
        """
        if reasons is None:
            reasons = []
        elif isinstance(reasons, str):
            reasons = [reasons]
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmstatus',
            call='setRestartRequired',
            args=[
                self.cluster._entities_to_keys(devices),
                reasons,
            ],
        )
        if code:
            raise OSError(out)
        return out

    def clear_restart_required(self, devices):
        """
        Set restart required for one or more devices.

        message: update the current status user message
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmstatus',
            call='clearRestartRequired',
            args=[self.cluster._entities_to_keys(devices)],
        )
        if code:
            raise OSError(out)
        return out

    def set_info_message(self, devices, message, low_level_update=False):
        """
        Set the info message for one or more devices.

        message: update the current status user message
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmstatus',
            call='setInfoMessage',
            args=[
                self.cluster._entities_to_keys(devices),
                message,
                low_level_update,
            ],
        )
        if code:
            raise OSError(out)
        return out

    def set_user_message(self, devices, message, low_level_update=False):
        """
        Set the info message for one or more devices.

        message: update the current status user message
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmstatus',
            call='setUserMessage',
            args=[
                self.cluster._entities_to_keys(devices),
                message,
                low_level_update,
            ],
        )
        if code:
            raise OSError(out)
        return out

    def set_tool_message(self, devices, message, low_level_update=False):
        """
        Set the info message for one or more devices.

        message: update the current status tool message
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmstatus',
            call='setToolMessage',
            args=[
                self.cluster._entities_to_keys(devices),
                message,
                low_level_update,
            ],
        )
        if code:
            raise OSError(out)
        return out

    def image_update(
        self,
        nodes,
        dry_run=False,
        wait=False,
        timeout: int | float | None = None,
        include_paths=None,
        selections=None,
    ):
        """
        Perform an image update on one or more devices.
        """
        if include_paths is None:
            include_paths = []
        if selections is None:
            selections = []
        node_keys = self.cluster._entities_to_keys(nodes)
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmprov',
            call='imageUpdate',
            args=[
                node_keys,
                dry_run,
                self.cluster.session_id,
                include_paths,
                selections,
            ],
        )
        if code:
            raise OSError(out)
        if wait and any(it > 0 for it in out):
            self.cluster.provisioning.wait(
                node_keys,
                timeout=timeout,
                source=False,
                destination=True,
            )
        return out

    def accelerators(self, nodes):
        """
        Get the number accelerators
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='getNodeAcceleratorCounts',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return zip(nodes, out)

    def system_information(self, nodes, basic=False, add_empty=False):
        """
        Get the system information for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='getSysInfoCollectors',
            args=[self.cluster._entities_to_keys(nodes), basic, add_empty],
        )
        if code:
            raise OSError(out)
        return [
            SysInfoCollector(
                self.cluster,
                it,
                parent=self.cluster.get_by_key(it['refDeviceUniqueKey']),
            )
            for it in out
        ]

    def update_system_information(self, nodes):
        """
        Get the system information for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='pupdateSysInfoCollectors',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return out

    def reload_managers(self, nodes):
        """
        Reload the entity managers on the nodes, use only when they are out of sync
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='preload',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return out

    def reboot(self, nodes, run_pre_halt_operations=True, pre_halt_operations_timeout=300):
        """
        Reboot one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='preboot',
            args=[
                run_pre_halt_operations,
                int(pre_halt_operations_timeout * 1000),
                self.cluster._entities_to_keys(nodes),
            ],
        )
        if code:
            raise OSError(out)
        operations = [BlockingOperation(self.cluster, it) for it in out['operations']]
        return {
            it[0]: (it[1], [jt for jt in operations if jt.refNodeUniqueKey == it[0]])
            for it in zip(nodes, out['success'])
        }

    def shutdown(self, nodes, run_pre_halt_operations=True, pre_halt_operations_timeout=300):
        """
        Shutdown one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='pshutdown',
            args=[
                run_pre_halt_operations,
                int(pre_halt_operations_timeout * 1000),
                self.cluster._entities_to_keys(nodes),
            ],
        )
        if code:
            raise OSError(out)
        operations = [BlockingOperation(self.cluster, it) for it in out['operations']]
        return {
            it[0]: (it[1], [jt for jt in operations if jt.refNodeUniqueKey == it[0]])
            for it in zip(nodes, out['success'])
        }

    def service_status(self, nodes, name: str | None = None):
        """
        Get the status of all or one service on one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        if name is None:
            (code, out) = rpc.call(
                service='cmserv',
                call='pgetOSServices',
                args=[self.cluster._entities_to_keys(nodes)],
            )
        else:
            (code, out) = rpc.call(
                service='cmserv',
                call='pgetOSService',
                args=[
                    name,
                    self.cluster._entities_to_keys(nodes),
                ],
            )
        if code:
            raise OSError(out)
        converter = EntityConverter(self.cluster, service=None)
        return [converter.convert(it) for it in out]

    def service_start(self, nodes, name: str, args=None):
        """
        Start a service on one or more nodes.
        """
        if args is None:
            args = []
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmserv',
            call='pstartOSService',
            args=[
                name,
                args,
                self.cluster._entities_to_keys(nodes),
            ],
        )
        if code:
            raise OSError(out)
        return out

    def service_stop(self, nodes, name: str, args=None):
        """
        Stop a service on one or more nodes.
        """
        if args is None:
            args = []
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmserv',
            call='pstopOSService',
            args=[
                name,
                args,
                self.cluster._entities_to_keys(nodes),
            ],
        )
        if code:
            raise OSError(out)
        return out

    def service_restart(self, nodes, name: str, args=None):
        """
        Restart a service on one or more nodes.
        """
        if args is None:
            args = []
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmserv',
            call='prestartOSService',
            args=[
                name,
                args,
                self.cluster._entities_to_keys(nodes),
            ],
        )
        if code:
            raise OSError(out)
        return out

    def service_reload(self, nodes, name: str, args=None):
        """
        Reload a service on one or more nodes.
        """
        if args is None:
            args = []
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmserv',
            call='preloadSService',
            args=[
                name,
                args,
                self.cluster._entities_to_keys(nodes),
            ],
        )
        if code:
            raise OSError(out)
        return out

    def service_reset(self, nodes, name: str, args=None):
        """
        Reset the failed count for a service on one or more nodes.
        """
        if args is None:
            args = []
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmserv',
            call='presetOSService',
            args=[
                name,
                args,
                self.cluster._entities_to_keys(nodes),
            ],
        )
        if code:
            raise OSError(out)
        return out

    def service_update(self, nodes, name: str, wait: bool = False) -> list[bool]:
        """
        Update a service and request an event to be send in response
        """
        rpc = self.cluster.get_rpc()
        nodes = self.cluster._entities_to_keys(nodes)
        (code, out) = rpc.call(
            service='cmserv',
            call='pupdateOSService',
            args=[
                name,
                self.cluster.session_id,
                nodes,
            ],
        )
        if code:
            raise OSError(out)
        if wait and sum(out):
            self.cluster.service_update_manager.wait(
                [node for node, updated in zip(nodes, out) if updated],
                name,
            )
        return out

    def active_command_status(
        self,
        internal=False,
        ids=None,
        nodes=None,
        command=None,
    ):
        """
        Get all active remote execute programmer runner status

        internal: also return programmer runners started by cmdaemon
        ids: return only status with matching IDs
        nodes: return only status if running on at least one node
        command: return only status if the command matches
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmproc',
            call='listCommands',
            args=[internal],
        )
        if code:
            raise OSError(out)
        status = [ProgramRunnerStatus(self.cluster, it) for it in out]
        if ids:
            status = [it for it in status if it.uniqueKey in ids]
        if nodes:
            status = [it for it in status if set(it.nodes) & set(nodes)]
        if command:
            status = [it for it in status if set(it.input.cmd) == command]
        return status

    def execute(
        self,
        nodes,
        command,
        args=None,
        env=None,
        user=None,
        run_in_shell=True,
        stdin=None,
        merge_stdout_stderr=False,
        max_run_time=None,
        wait=True,
        timeout=None,
        info=None,
    ):
        """
        Execute a command on one or more nodes.

        nodes: list of nodes to execute the command.
        command: command to be executes.
        args: additional arguments to the command.
        env: extra environment variables to be set.
        user: execute the command as a specific user.
        run_in_shell: run the command inside the users default shell.
        stdin: data to be passed to the processes standard in.
        merge_stdout_stderr: merge standard out and error into one.
        max_run_time: maximal runtime before the script gets killed.
        wait: wait for completion.
        timeout: time for python to wait, the script will continue to run.
        info: additional info for debugging purposes
        """
        program_runner_input = ProgramRunnerInput()
        program_runner_input.cmd = command
        program_runner_input.mergeCoutCerr = merge_stdout_stderr
        program_runner_input.startInShell = run_in_shell
        if args is not None:
            program_runner_input.args = args
        if env is not None:
            program_runner_input.env = env
        if info is not None:
            program_runner_input.info = info
        if stdin is not None:
            program_runner_input.datacin = stdin
        if max_run_time is not None:
            program_runner_input.maxruntime = max_run_time
        if user is None:
            program_runner_input.user = pwd.getpwuid(os.getuid())[0]
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmproc',
            call='runCommand',
            args=[
                self.cluster._entities_to_keys(nodes),
                program_runner_input,
                self.cluster.session_id,
            ],
        )
        if code:
            raise OSError(out)
        program_runner_status = ProgramRunnerStatus(self.cluster, out)
        self.cluster.remote_execution_manager.register(program_runner_status)
        done = None
        if wait:
            done = program_runner_status.wait(timeout)
            if done:
                self.cluster.remote_execution_manager.unregister(program_runner_status)
        return done, program_runner_status

    def drain_status(
        self,
        nodes,
        wlms=None,
    ):
        """
        Get the workload managers drain status for one or more nodes.
        """
        if wlms is None:
            wlms = []
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmjob',
            call='drainOverview',
            args=[
                self.cluster._entities_to_keys(wlms),
                self.cluster._entities_to_keys(nodes),
            ],
        )
        if code:
            raise OSError(out)
        return [DrainResult(self.cluster, it) for it in out]

    def drain(
        self,
        nodes,
        wlms=None,
        queues=None,
        add_actions=None,
        remove_actions=None,
        clear_actions=False,
        reason='',
        drain=True,
    ):
        """
        Drain one or more nodes in workload managers.
        """
        if wlms is None:
            wlms = []
        if queues is None:
            queues = []
        if add_actions is None:
            add_actions = []
        if remove_actions is None:
            remove_actions = []
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmjob',
            call='drainNodes',
            args=[
                self.cluster._entities_to_keys(wlms),
                self.cluster._entities_to_keys(queues),
                self.cluster._entities_to_keys(nodes),
                drain,
                add_actions,
                remove_actions,
                clear_actions,
                reason,
            ],
        )
        if code:
            raise OSError(out)
        return [DrainResult(self.cluster, it) for it in out.get('results', [])]

    def undrain(
        self,
        nodes,
        wlms=None,
        queues=None,
    ):
        """
        Undrain one or more nodes.
        """
        return self.drain(
            nodes=nodes,
            wlms=wlms,
            queues=queues,
            drain=False,
        )

    def drain_status_kube(self, nodes):
        """
        Get the workload managers drain status for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmkube',
            call='drainOverview',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [DrainResult(self.cluster, it) for it in out]

    def drain_kube(
        self,
        nodes,
        add_actions=None,
        remove_actions=None,
        clear_actions=False,
        drain=True,
    ):
        """
        Drain one or more nodes in workload managers.
        """
        if add_actions is None:
            add_actions = []
        if remove_actions is None:
            remove_actions = []
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmkube',
            call='drainNodes',
            args=[
                self.cluster._entities_to_keys(nodes),
                drain,
                add_actions,
                remove_actions,
                clear_actions,
            ],
        )
        if code:
            raise OSError(out)
        return [DrainResult(self.cluster, it) for it in out.get('results', [])]

    def undrain_kube(self, nodes):
        """
        Undrain one or more nodes.
        """
        return self.drain_kube(nodes=nodes, drain=False)

    def drain_status_ceph(self, nodes):
        """
        Get the workload managers drain status for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmceph',
            call='drainOverview',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [DrainResult(self.cluster, it) for it in out]

    def drain_ceph(
        self,
        nodes,
        add_actions=None,
        remove_actions=None,
        clear_actions=False,
        drain=True,
    ):
        """
        Drain one or more nodes in workload managers.
        """
        if add_actions is None:
            add_actions = []
        if remove_actions is None:
            remove_actions = []
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmceph',
            call='drainNodes',
            args=[
                self.cluster._entities_to_keys(nodes),
                drain,
                add_actions,
                remove_actions,
                clear_actions,
            ],
        )
        if code:
            raise OSError(out)
        return [DrainResult(self.cluster, it) for it in out.get('results', [])]

    def undrain_ceph(self, nodes):
        """
        Undrain one or more nodes.
        """
        return self.drain_ceph(nodes=nodes, drain=False)

    def terminate(self, nodes):
        """
        Terminate one or more cloud nodes.
        """
        cloud_nodes = []
        for node in nodes:
            if isinstance(node, int):
                node = self.cluster.get_by_key(node)
            if isinstance(node, CloudNode):
                cloud_nodes.append(node)
        out_cloud = None
        out_virtual = None
        if len(cloud_nodes):
            rpc = self.cluster.get_rpc()
            (code, out_cloud) = rpc.call(
                service='cmcloud',
                call='terminate',
                args=[self.cluster._entities_to_keys(cloud_nodes)],
            )
            if code:
                raise OSError(out_cloud)
        return out_cloud, out_virtual

    def connectivity(self, nodes, count=1, delay=1.0, ping_timeout=1.0, global_timeout=350.0):
        """
        Terminate one or more cloud nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='parallelPingAllToAll',
            args=[
                self.cluster._entities_to_keys(nodes),
                count,
                int(delay * 1000),
                int(ping_timeout * 1000),
                int(global_timeout * 1000),
            ],
        )
        if code:
            raise OSError(out)
        return [PingResult(self.cluster, it) for it in out]

    def burn_status(self, nodes):
        """
        Get the burn status for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='getBurnStatus',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [BurnStatus(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey'])) for it in out]

    def version_info(self, nodes) -> list[VersionInfo]:
        """
        Get the version information for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='pgetVersion',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [VersionInfo(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey'])) for it in out]

    def update_GNSS_location(self, nodes: list[int | Node]) -> list[bool]:
        """
        Asynchronously update the GNSS locations for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmpart',
            call='pupdateGNSSLocation',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return out

    def routes(self, nodes):
        """
        Get the routes one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='proutes',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [Route(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey'])) for it in out]

    def bios_apply(self, nodes) -> list[ExternalOperationResult]:
        """
        Apply the configured BIOS setup for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='biosApply',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def bios_check(self, nodes) -> list[ExternalOperationResult]:
        """
        Check the configured BIOS setup matches the live version for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='biosCheck',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def bios_fetch(self, nodes) -> list[ExternalOperationResult]:
        """
        Fetch the live BIOS setup for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='biosFetch',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def firmware_info(self, nodes: list[int | Node]) -> list[FirmwareInfo]:
        """
        Get information on the available firmware files for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='firmwareFileInfo',
            args=[self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [FirmwareInfo(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey'])) for it in out]

    def firmware_repository_info(
        self,
        nodes: list[int | Node],
        debug: bool = False,
    ) -> list[ExternalOperationResult]:
        """
        Get information on the firmware files on the iLO repository for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='firmwareRepositoryInfo',
            args=[self.cluster._entities_to_keys(nodes), debug],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def firmware_upload(
        self,
        nodes: list[int | Node],
        files: list[str],
        debug: bool = False,
    ) -> list[ExternalOperationResult]:
        """
        Upload firmware onto the iLO repository for one or more nodes
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='firmwareUpload',
            args=[self.cluster._entities_to_keys(nodes), files, debug],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def firmware_flash(
        self,
        nodes: list[int | Node],
        files: list[str],
        debug: bool = False,
    ) -> list[ExternalOperationResult]:
        """
        Flash firmware from the iLO repository for one or more nodes
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='firmwareFlash',
            args=[
                self.cluster._entities_to_keys(nodes),
                files,
                debug,
            ],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def firmware_status(
        self,
        nodes: list[int | Node],
        debug: bool = False,
    ) -> list[ExternalOperationResult]:
        """
        Get information on the firmware status for one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='firmwareStatus',
            args=[self.cluster._entities_to_keys(nodes), debug],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def firmware_remove(
        self,
        nodes: list[int | Node],
        files: list[str],
        debug: bool = False,
    ) -> list[ExternalOperationResult]:
        """
        Remove firmware from the iLO repository for one or more nodes
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='firmwareRemove',
            args=[self.cluster._entities_to_keys(nodes), files, debug],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def network_connections(self, nodes, tcp=True, udp=True, tcp6=True, udp6=True):
        """
        Get the network connections one or more nodes.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='pnetworkConnections',
            args=[tcp, udp, tcp6, udp6, self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [
            NetworkConnection(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey'])) for it in out
        ]

    def additional_information(self, nodes, name=None, run_on_active_head_node=False):
        """
        Get the network connections one or more nodes.
        """
        command = '' if name is None else name
        rpc = self.cluster.get_rpc()
        if run_on_active_head_node:
            (code, out) = rpc.call(
                service='cmdevice',
                call='getAdditionalNodeInfoForNodes',
                args=[command, self.cluster._entities_to_keys(nodes)],
            )
        else:
            (code, out) = rpc.call(
                service='cmdevice',
                call='pgetAdditionalNodeInfo',
                args=[command, self.cluster._entities_to_keys(nodes)],
            )
        if code:
            raise OSError(out)
        elif len(out) == 0:
            return None
        elif name is None:
            return list({it for jt in out['path'] for it in jt.split(',')})
        result = []
        for node, path, stdout, stderr, exit_code in zip(
            nodes, out['path'], out['stdout'], out['stdout'], out['exit_code']
        ):
            result.append(
                {
                    'node': node,
                    'path': path,
                    'stdout': stdout,
                    'stderr': stderr,
                    'exit_code': exit_code,
                }
            )
        return result

    def get_all_installed_packages(self, nodes: list[int], root: str = '') -> list[Package]:
        """
        Get all installed packages
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='pallPackages',
            args=[root, self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [Package(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey'])) for it in out]

    def find_installed_packages(
        self,
        nodes: list[int],
        names: str | list[str],
        root: str = '',
    ) -> list[Package]:
        """
        Find one or more installed packages
        """
        if isinstance(names, str):
            names = [names]
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='pgetPackages',
            args=[root, names, self.cluster._entities_to_keys(nodes)],
        )
        if code:
            raise OSError(out)
        return [Package(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey'])) for it in out]

    def power_history(self, devices, last: bool = False):
        """
        Get the power history for one or more devices.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='powerOperationHistory',
            args=[self.cluster._entities_to_keys(devices), last],
        )
        if code:
            raise OSError(out)
        return [
            PowerOperationHistory(self.cluster, it, parent=self.cluster.get_by_key(it['refDeviceUniqueKey']))
            for it in out
        ]

    def bmc_identify(self, nodes: list[int], debug: bool = False) -> list[ExternalOperationResult]:
        """
        Identify nodes via the BMC led
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='bmcIdentify',
            args=[self.cluster._entities_to_keys(nodes), True, debug],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def bmc_unidentify(self, nodes: list[int], debug: bool = False) -> list[ExternalOperationResult]:
        """
        Unidentify nodes via the BMC led
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='bmcIdentify',
            args=[self.cluster._entities_to_keys(nodes), False, debug],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def bmc_is_identified(self, nodes: list[int], debug: bool = False) -> list[ExternalOperationResult]:
        """
        Check if nodes are indentfied via the BMC led
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='bmcIsIdentified',
            args=[self.cluster._entities_to_keys(nodes), debug],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def bmc_reset(self, nodes: list[int], debug: bool = False) -> list[ExternalOperationResult]:
        """
        Reset the BMC controller
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='bmcReset',
            args=[self.cluster._entities_to_keys(nodes), debug],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def bmc_event_logs(self, nodes: list[int], debug: bool = False) -> list[ExternalOperationResult]:
        """
        Get the event logs from a BMC controller
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='bmcEventLogs',
            args=[self.cluster._entities_to_keys(nodes), debug],
        )
        if code:
            raise OSError(out)
        return [
            ExternalOperationResult(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]
