#
# SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

from __future__ import annotations

from pythoncm.entity import KeyValuePair
from pythoncm.entity.metadata.keyvaluepair import KeyValuePair as KeyValuePairMeta


class KeyValueStore:
    """
    Helper class-wrapper for key/value store API
    """

    def __init__(self, cluster):
        self.cluster = cluster

    def set(self, key: str, value: str) -> tuple[KeyValuePairMeta.RCPResult, int, int]:
        """
        Set a key/value pair
        """
        key_value_pair = KeyValuePair(data={'key': key, 'value': value})

        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmkeyvalue',
            call='keyValueStoreCommitOperations',
            args=[[], [key_value_pair], self.cluster.session_id],
        )
        if code:
            raise OSError(out)
        return (
            KeyValuePairMeta.RCPResult[out.get('status', 'Ok')],
            out.get('num_updated', 0),
            out.get('num_removed', 0),
        )

    def get(
        self,
        keys: str | list[str],
        predicate: KeyValuePairMeta.Predicate = KeyValuePairMeta.Predicate.Equals,
    ) -> tuple[int, list[KeyValuePair]]:
        """
        Get all key/value pairs that match the given keys under the predicate
        """
        if isinstance(keys, str):
            keys = [keys]
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmkeyvalue',
            call='keyValueStoreGetPairs',
            args=[predicate.name, keys],
        )
        if code:
            raise OSError(out)
        return (
            KeyValuePairMeta.RCPResult[out.get('status', 'Ok')],
            [KeyValuePair(self.cluster, it) for it in out.get('result', [])],
        )

    def remove(self, keys: str | list[str]) -> tuple[KeyValuePairMeta.RCPResult, int]:
        """
        Remove all key/value pairs that match the exact keys
        """
        if isinstance(keys, str):
            keys = [keys]
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmkeyvalue',
            call='keyValueStoreCommitOperations',
            args=[keys, [], self.cluster.session_id],
        )
        if code:
            raise OSError(out)
        return (
            KeyValuePairMeta.RCPResult[out.get('status', 'Ok')],
            out.get('num_removed', 0),
        )

    def purge(
        self,
        keys: str | list[str],
        predicate: KeyValuePairMeta.Predicate = KeyValuePairMeta.Predicate.Equals,
    ) -> tuple[KeyValuePairMeta.RCPResult, int]:
        """
        Remove all key/value pairs that match the given keys under the predicate
        """
        if isinstance(keys, str):
            keys = [keys]
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmkeyvalue',
            call='keyValueStorePurge',
            args=[predicate.name, keys, self.cluster.session_id],
        )
        if code:
            raise OSError(out)
        return (
            KeyValuePairMeta.RCPResult[out.get('status', 'Ok')],
            out.get('num_removed', 0),
        )
