#
# SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

from __future__ import annotations

from pythoncm.entity import MonitoringDataProducer
from pythoncm.entity import MonitoringSubSystemInfo
from pythoncm.monitoring.enum_value_cache import EnumValueCache
from pythoncm.monitoring.info_message_cache import InfoMessageCache
from pythoncm.monitoring.plot.health_overview import HealthOverview
from pythoncm.monitoring.plot.result import Result
from pythoncm.monitoring.prometheus import Prometheus


class Monitoring:
    def __init__(self, cluster):
        self.cluster = cluster
        self.prometheus = Prometheus(self.cluster)
        self.info_message_cache = InfoMessageCache(self.cluster)
        self.enum_value_cache = EnumValueCache(self.cluster)

    def connect(self):
        self.enum_value_cache.update()

    def _get_all_entities(self, timeout=None):
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmmon',
            call='getMonitoredEntities',
            timeout=timeout,
        )
        if code:
            raise OSError(out)
        return out

    def _get_all_measurables(self, entities, timeout=None):
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmmon',
            call='getMonitoringMeasurablesForEntities',
            args=[entities],
            timeout=timeout,
        )
        if code:
            raise OSError(out)
        measurables = out.get('measurables', [])
        return list(set(measurables))

    def _get_entities_measurables(self, entities, measurables, timeout=None):
        if entities is None:
            entities = self._get_all_entities(timeout)
        else:
            entities = self.cluster._entities_to_keys(entities)
        if measurables is None:
            measurables = self._get_all_measurables(entities, timeout)
        else:
            measurables = self.cluster._entities_to_keys(measurables)
        return entities, measurables

    def get_all_entity_measurables(self, timeout=None):
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmmon',
            call='getAllEntityMeasurables',
            timeout=timeout,
        )
        if code:
            raise OSError(out)
        return out.get('entities', []), out.get('measurables', [])

    def dump_monitoring_data(
        self,
        entities,
        start_time,
        end_time,
        measurables=None,
        intervals=0,
        timeout=None,
        clip=False,
        uncompress=False,
        pair_wise=False,
    ):
        """
        Dump monitoring data

        entities:      list of entities/keys to dump data for
        measurables:   list of measurables/keys to dump data for
        range_start:   dump range start in epoch
        range_end:     dump end start in epoch
        intervals:     number of interpolation intervals (0 for raw data)
        clip:          clip the first and last data point to exactly the supplied range
        uncompress:    uncompress run lenght compressed data
        pair_wise:     treat the entities and measurables as pairs not combinations
        """
        entities, measurables = self._get_entities_measurables(entities, measurables)
        request = {
            'entities': entities,
            'measurables': measurables,
            'range_start': start_time * 1000,
            'range_end': end_time * 1000,
            'intervals': intervals,
            'clip': clip,
            'uncompress': uncompress,
            'pair_wise': pair_wise,
        }
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmmon',
            call='plot',
            args=[request],
            timeout=timeout,
        )
        if code:
            raise OSError(out)
        return Result(self.cluster, request, out)

    def get_latest_monitoring_data(
        self,
        entities,
        measurables=None,
        include_measurable_status=False,
        timeout=None,
        counter=False,
    ):
        """
        Get the latest monitoring data.
        """
        entities, measurables = self._get_entities_measurables(entities, measurables)
        request = {
            'entities': entities,
            'measurables': measurables,
            'include_measurable_status': include_measurable_status,
            'data_type': 'COUNTER' if counter else 'CUMULATIVE',
        }
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmmon',
            call='plot',
            args=[request],
            timeout=timeout,
        )
        if code:
            raise OSError(out)
        return Result(self.cluster, request, out, latest=True)

    def sample_now(self, entities, measurables=None, env=None, timeout=None):
        """
        Live sample measurables.
        """
        entities, measurables = self._get_entities_measurables(entities, measurables)
        request = {
            'entities': entities,
            'measurables': measurables,
        }
        if env is not None:
            request['env'] = env
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmmon',
            call='sample',
            args=[request],
            timeout=timeout,
        )
        if code:
            raise OSError(out)
        return Result(self.cluster, request, out, latest=True)

    def health_overview(self, entities=None, timeout=None):
        """
        Get a overview of all failing or unknown health checks.
        """
        health_overview = HealthOverview(self.cluster)
        measurables = health_overview.get_measurables()
        if len(measurables) == 0:
            raise ValueError('Unable to find any AlertLevel measurable')
        measurables = [it.uniqueKey for it in measurables]
        if entities is None:
            entities = self._get_all_entities()
        else:
            entities = self.cluster._entities_to_keys(entities)
        request = {
            'entities': entities,
            'measurables': measurables,
        }
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmmon',
            call='plot',
            args=[request],
            timeout=timeout,
        )
        if code:
            raise OSError(out)
        health_overview.update(out)
        return health_overview

    def system_information(self, nodes, timeout=None):
        """
        Get detailed information on the monitoring system.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='psubSystemInfo',
            args=[self._entities_to_keys(nodes)],
            timeout=timeout,
        )
        if code:
            raise OSError(out)
        return [
            MonitoringSubSystemInfo(self.cluster, it, parent=self.cluster.get_by_key(it['refNodeUniqueKey']))
            for it in out
        ]

    def reinitialize(self, producers=None, entities=None, timeout=None):
        """
        For reinitialize of monitoring data producers.
        """
        if entities is None:
            entities = []
        if producers is None:
            producers = self.cluster.get_by_type(MonitoringDataProducer)
        producer_keys = self.cluster._entities_to_keys(producers)
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmmon',
            call='getEntitiesForMonitoringDataProducers',
            args=[producer_keys],
            timeout=timeout,
        )
        if code:
            raise OSError(out)
        node_keys = out
        (code, out) = rpc.call(
            service='cmmon',
            call='preinitializeDataProducers',
            args=[
                producer_keys,
                self.cluster._entities_to_keys(entities),
                node_keys,
            ],
            timeout=timeout,
        )
        if code:
            raise OSError(out)
        return list(zip(node_keys, out))

    def trigger_information(self, nodes, timeout=None):
        """
        Get low level information on monitoring triggers.
        """
        rpc = self.cluster.get_rpc()
        (code, out) = rpc.call(
            service='cmmon',
            call='getTriggerEvaluationData',
            timeout=timeout,
        )
        if code:
            raise OSError(out)
        return out
