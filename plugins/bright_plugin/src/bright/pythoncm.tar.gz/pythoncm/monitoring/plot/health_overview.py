#
# SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

from __future__ import annotations

import json
import logging
from time import time

from tabulate import tabulate

from pythoncm import util as util


class HealthOverview:
    """
    Helper class to display health overview
    """

    def __init__(self, cluster):
        self.cluster = cluster
        self.logger = logging.getLogger(__name__)
        self.health_overview = None

    def alter_level_types(self):
        return ['sum', 'count', 'maximum']

    def get_measurables(self):
        alert_level = [
            self.cluster.get_by_name(f'AlertLevel:{it}', 'MonitoringMeasurableMetric')
            for it in self.alter_level_types()
        ]
        measurables = [it for it in alert_level if it is not None]
        return measurables

    def update(self, data):
        measurables = {it.uniqueKey: it for it in self.get_measurables() if it is not None}
        info_message_keys = list({it['info'] for it in data.get('items', []) if it.get('info', '0') != '0'})
        self.cluster.monitoring.info_message_cache.ensure(info_message_keys)
        health_overview = dict()
        now = time()
        types = self.alter_level_types()
        for item in data.get('items', []):
            entity = self.cluster.get_by_key(item.get('entity', 0))
            if entity is None:
                entity_name = item.get('entity', 0)
            else:
                entity_name = entity.resolve_name
            measurable = measurables[item.get('measurable', 0)]
            if entity_name not in health_overview:
                timestamp = util.format_milli_seconds_time_stamp(
                    value=item.get('t1', 0),
                    now=now,
                    latest=True,
                )
                info = self.cluster.monitoring.info_message_cache.get(item.get('info', '0'))
                if info is not None and len(info):
                    try:
                        info = [self.cluster.resolve_name_by_key(int(it)) for it in json.loads(info)]
                        info = '\n'.join(info)
                    except Exception as e:
                        self.logger.info('Bad alert level info: %s, error: %s', info, e)
                health_overview[entity_name] = [0, 0, 0, timestamp, info]
            try:
                index = types.index(measurable.parameter)
                health_overview[entity_name][index] = item.get('value', 0)
            except Exception as e:
                self.logger.info('Unknown alert level parameter: %s, error: %s', measurable.parameter, e)
        self.health_overview = [[key] + values for (key, values) in health_overview.items()]
        self.health_overview.sort()

    def to_string(self, table_format='rst', showindex='default'):
        """
        Create a nice formatted table for printing.
        """
        return tabulate(
            self.health_overview,
            tablefmt=table_format,
            showindex=showindex,
            headers=[
                "Entity",
                "Sum",
                "Count",
                "Maximum",
                "Time",
                "Info",
            ],
        )
