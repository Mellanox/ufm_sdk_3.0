#
# SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

from __future__ import annotations

import atexit
import json
import logging
import os
import threading
import time
import typing

from pythoncm.background_task_manager import BackgroundTaskManager
from pythoncm.component_certificate import ComponentCertificate
from pythoncm.device_status_waiter_manager import DeviceStatusWaiterManager
from pythoncm.entity import ClusterSetup
from pythoncm.entity import CMDaemonStatus
from pythoncm.entity import FileWriteInfo
from pythoncm.entity import GuiClusterOverview
from pythoncm.entity import LicenseInfo
from pythoncm.entity import VersionInfo
from pythoncm.entity.certificate import Certificate
from pythoncm.entity.certificaterequest import CertificateRequest
from pythoncm.entity.entity import Entity
from pythoncm.entity.fspart import FSPart
from pythoncm.entity.newnode import NewNode
from pythoncm.entity.node import Node
from pythoncm.entity.remotenodeinstallerinteraction import RemoteNodeInstallerInteraction
from pythoncm.entity_change import EntityChange
from pythoncm.entity_converter import EntityConverter
from pythoncm.event_handler import EventHandler
from pythoncm.ha import HA
from pythoncm.key_value_store import KeyValueStore
from pythoncm.meta_data_cache import MetaDataCache
from pythoncm.monitoring.monitoring import Monitoring
from pythoncm.multi_commit_result import MultiCommitResult
from pythoncm.multi_remove_result import MultiRemoveResult
from pythoncm.parallel import Parallel
from pythoncm.power_operation_manager import PowerOperationManager
from pythoncm.provisioning import Provisioning
from pythoncm.remote_execution_manager import RemoteExecutionManager
from pythoncm.rpc.rpc import RPC
from pythoncm.rpc.service import Service
from pythoncm.service_update_manager import ServiceUpdateManager
from pythoncm.settings import Settings
from pythoncm.target_source_mapping import TargetSourceMapping
from pythoncm.workload import Workload

try:
    from pythoncm.entity.metadata.api import API
except ImportError:
    API = None

if typing.TYPE_CHECKING:
    from collections.abc import Iterable

EntityT = typing.TypeVar('EntityT', bound=Entity)  # Special type used for linking of argument type and return type


class Cluster:
    """
    The pythoncm connection to the active head node cmdaemon
    """

    MAX_LOCAL_KEY = (2**32) - 1
    CLIENT_TYPE_PYTHON = 6
    WAIT_FOR_EVENT_TIMEOUT = 10

    REDIRECT_NONE = 0
    REDIRECT_ACTIVE_HEAD = 1
    REDIRECT_SHARED_IP = 2

    def __init__(
        self,
        settings=None,
        auto_connect=True,
        follow_redirect=REDIRECT_ACTIVE_HEAD,
        check_api=True,
    ):
        if settings is None:
            home = os.path.expanduser('~')
            cert_paths = [f'{home}/{path}' for path in ('.cm', '.cm/cmsh')]
            cert_path = None
            for path in cert_paths:
                if os.path.exists(f'{path}/admin.pem') and os.path.exists(f'{path}/admin.key'):
                    cert_path = path
                    break
            assert cert_path
            self.settings = Settings(
                cert_file=f'{cert_path}/admin.pem',
                key_file=f'{cert_path}/admin.key',
                ca_file='/cm/local/apps/cmd/etc/cacert.pem',
            )
        else:
            self.settings = settings

        self.logger = logging.getLogger(__name__)

        self._all_services = [
            Service('cmauth', 'CMService', 'CMServices'),
            Service('cmauth', 'Profile', 'Profiles'),
            Service('cmceph', 'Ceph', 'Cephs'),
            Service('cmceph', 'CephOSDPool', 'CephOSDPools'),
            Service('cmcloud', 'CMJobConfig', 'CMJobConfigs'),
            Service('cmcloud', 'CloudProvider', 'CloudProviders', by_keys=True),
            Service('cmcloud', 'CloudRegion', 'CloudRegions', by_keys=True),
            Service('cmcloud', 'CloudType', 'CloudTypes', by_keys=True),
            Service('cmcloud', 'CloudJobDescription', 'CloudJobDescriptions'),
            Service('cmdevice', 'Category', 'Categories', by_keys=True, multi=True),
            Service('cmdevice', 'ConfigurationOverlay', 'ConfigurationOverlays', by_keys=True),
            Service('cmdevice', 'Device', 'Devices', by_keys=True, multi=True),
            Service('cmdevice', 'NodeGroup', 'NodeGroups', by_keys=True, multi=True),
            Service('cmdevice', 'NodeHierarchyRule', 'NodeHierarchyRules', by_keys=True),
            Service('cmdevice', 'UnmanagedNodeConfiguration', 'UnmanagedNodeConfigurations', by_keys=True),
            Service('cmdevice', 'ReportQuery', 'ReportQueries', by_keys=True, multi=True),
            Service('cmetcd', 'EtcdCluster', 'EtcdClusters'),
            Service('cmjob', 'JobQueue', 'JobQueues', owner=True, by_keys=True),
            Service('cmjob', 'WlmCluster', 'WlmClusters', by_keys=True),
            Service('cmjob', 'ChargeBackRequest', 'ChargeBackRequests', by_keys=True),
            Service('cmkube', 'KubeCluster', 'KubeClusters', by_keys=True),
            Service('cmmon', 'LabeledEntity', 'LabeledEntities', by_keys=True),
            Service('cmmon', 'MonitoringAction', 'MonitoringActions', by_keys=True),
            Service('cmmon', 'MonitoringConsolidator', 'MonitoringConsolidators', by_keys=True),
            Service('cmmon', 'MonitoringDataProducer', 'MonitoringDataProducers', by_keys=True),
            Service('cmmon', 'MonitoringMeasurable', 'MonitoringMeasurables', by_keys=True),
            Service('cmmon', 'MonitoringTrigger', 'MonitoringTriggers', by_keys=True),
            Service('cmmon', 'PrometheusQuery', 'PrometheusQueries', by_keys=True),
            Service('cmmon', 'StandaloneMonitoredEntity', 'StandaloneMonitoredEntities', by_keys=True),
            Service('cmnet', 'Network', 'Networks', by_keys=True, multi=True),
            Service('cmpart', 'Partition', 'Partitions'),
            Service('cmpart', 'Rack', 'Racks'),
            Service('cmpart', 'EdgeSite', 'EdgeSites', by_keys=True, multi=True),
            Service('cmpart', 'SoftwareImage', 'SoftwareImages', by_keys=True, multi=True),
            Service('cmpart', 'SoftwareImageFileSelection', 'SoftwareImageFileSelections'),
            Service('cmprov', 'FSPart', 'FSParts', by_keys=True),
            Service('cmuser', 'Group', 'Groups'),
            Service('cmuser', 'User', 'Users'),
            Service('cmbeegfs', 'BeeGFSCluster', 'BeeGFSClusters', by_keys=True),
        ]
        self.entities = None
        self._entities_condition = threading.Condition()
        self._delayed_updates = []
        self.fetch_errors = None
        self.connected = False
        self.session_id = None
        self.warnings = None
        self._event_thread = None
        self._event_handler = EventHandler(self)
        self._next_local_key = 0
        self._active_passive_keys = None
        self.monitoring = Monitoring(self)
        self.background_task_manager = BackgroundTaskManager(self)
        self.device_status_waiter_manager = DeviceStatusWaiterManager(self)
        self.power_operation_manager = PowerOperationManager(self)
        self.remote_execution_manager = RemoteExecutionManager(self)
        self.meta_data_cache = MetaDataCache(self)
        self.key_value_store = KeyValueStore(self)
        self.provisioning = Provisioning(self)
        self.parallel = Parallel(self)
        self.workload = Workload(self)
        self.component_certificate = ComponentCertificate(self)
        self.entity_change = EntityChange()
        self.service_update_manager = ServiceUpdateManager()
        self.ha = HA(self)
        self.certificate = None
        self.profile = None
        if bool(self.settings) and self.settings.check_certificate_files():
            self.certificate = Certificate()
            self.certificate.cluster = self
            self.certificate.load(self.settings.cert_file)
        if auto_connect:
            self.connect(
                follow_redirect=follow_redirect,
                check_api=check_api,
            )
        atexit.register(self.disconnect)

    def check_api(self):
        """
        Check if the cmdaemon is running the same API.
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='verifyAPI',
            args=['pythoncm', API.hash],
        )
        if code:
            raise OSError(out)
        return out

    def follow_redirect(self, follow_redirect):
        """
        Connect to the shared IP in case of a HA setup.
        """
        if follow_redirect == self.REDIRECT_NONE:
            self.logger.info('No redirection, using: %s', self.settings.host)
            return True
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='getMasterIPs',
        )
        if code:
            raise OSError(out)
        active_ip = out.get('currentMasterIP', None)
        shared_ip = out.get('sharedIP', None)
        if follow_redirect == self.REDIRECT_ACTIVE_HEAD and active_ip is not None:
            if self.settings.update_host(active_ip):
                self.logger.info('Follow redirection to active head IP: %s', active_ip)
                return True
        elif follow_redirect == self.REDIRECT_SHARED_IP and shared_ip is not None:
            if self.settings.update_host(shared_ip):
                self.logger.info('Follow redirection to shared IP: %s', active_ip)
                return True
        else:
            self.logger.info('No redirection required, using: %s', self.settings.host)
        return False

    def connect(self, follow_redirect=REDIRECT_ACTIVE_HEAD, check_api=True, force_reconnect=False):
        """
        Connect to the cluster and load all entities.
        """
        if self.connected and not force_reconnect:
            self.logger.info('Already connected to cluster')
            return True
        elif check_api:
            if not self.check_api():
                raise ValueError('Invalid API hash')
            self.logger.debug('Cluster API compatibile')
        else:
            self.logger.warning('API compatibility not checked')
        if not self.follow_redirect(follow_redirect):
            return False
        self._refresh_all()
        self._register_session()
        self._start_event_thread()
        self.monitoring.connect()
        if self.certificate is not None:
            self.profile = self.get_by_name(self.certificate.profile, 'Profile')
            if self.profile is None:
                self.logger.warning('Unable to find profile: %s', self.certificate.profile)
        self.connected = True
        return True

    def _refresh_all(self):
        (entities, self.fetch_errors) = self._fetch()
        if len(entities) == 0:
            names = {str(it) for it in self.fetch_errors}
            raise OSError(f"Unable to connect: {', '.join(names)}")
        with self._entities_condition:
            self.entities = {it.uniqueKey: it for it in entities}
            [entity._resolve_keys() for entity in self.entities.values()]

    def disconnect(self, throw=False):
        """
        Disconnect from the cluster.
        """
        if self.connected:
            exception: BaseException | None = None
            try:
                self._unregister_session()
            except Exception:
                pass
            self._stop_event_thread()
            self.entity_change.stop()
            self.fetch_errors = None
            self.connected = False
            with self._entities_condition:
                self.entities = None
            if throw and exception is not None:
                raise exception

    def _register_session(self):
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmsession',
            call='registerSession',
            args=[self.CLIENT_TYPE_PYTHON],
        )
        if code:
            raise OSError(out)
        self.warnings = []
        self.session_id = out
        self.logger.debug('Registered session %d', self.session_id)
        return self.session_id > 0

    def _unregister_session(self):
        if self.session_id is None:
            return False
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmsession',
            call='unregisterSession',
            args=[self.session_id],
        )
        if code:
            raise OSError(out)
        self.logger.debug('Unregistered session %d', self.session_id)
        self.session_id = None
        return out

    def _start_event_thread(self):
        if self.session_id is None:
            raise ValueError('No valid session')
        elif self._event_thread is not None:
            self._stop_event_thread()
        self.logger.info('Start event thread for session %d', self.session_id)
        self._event_thread = threading.Thread(target=self._wait_for_events)
        self._event_thread.daemon = True
        self._event_thread.start()

    def _stop_event_thread(self):
        if self._event_thread is None:
            raise ValueError('Event thread not running')
        self._event_thread.join()
        self._event_thread = None

    def _wait_for_events(self):
        rpc = self.get_rpc()
        while self.session_id is not None:
            (code, out) = rpc.call(
                service='cmsession',
                call='waitForEvents',
                args=[self.session_id, self.WAIT_FOR_EVENT_TIMEOUT],
            )
            if code:
                self.logger.debug('End waiting for events, code: %d', code)
                break
            elif self._event_handler.handle(out):
                self.connected = False
                self.logger.debug('End waiting for events, needed to stop')
                break

    def _end_of_session(self, reason):
        self.logger.debug('Session ended, reason: %s', reason)

    def _add_warning(self, uniqueKey, message, extended_message):
        self.warnings.append((uniqueKey, message, extended_message))
        self.logger.debug('New warning: "%s", total: %d', message, len(self.warnings))

    def get_rpc(self) -> RPC:
        return RPC(self.settings)

    def next_local_key(self) -> int:
        self._next_local_key += 1
        return self._next_local_key

    def add(self, entity, force_keys=False) -> int:
        """
        Add a new entity to the cluster.
        """
        if self.entities is None:
            return entity.uniqueKey
        elif not isinstance(entity, Entity):
            raise ValueError('No valid entity supplied')
        elif not entity.meta.top_level:
            raise ValueError('Not a top level entity')
        elif entity._cluster is not None and entity._cluster != self:
            raise ValueError('Already added to a different cluster')
        elif (entity.uniqueKey > self.MAX_LOCAL_KEY) and not force_keys:
            raise ValueError('Already added and committed')
        elif (entity.uniqueKey != 0) and not force_keys:
            raise ValueError('Already added')
        if entity._cluster is None:
            entity._cluster = self
        if entity._service is None:
            entity._service = self._find_service(entity.meta.service_type)
        with self._entities_condition:
            entity._set_unique_keys(self, force=force_keys)
            self.entities[entity.uniqueKey] = entity
        return entity.uniqueKey

    def _find_service(self, service_type: str):
        return next(it for it in self._all_services if it.name == service_type)

    def _move_key(self, old_key, new_key):
        with self._entities_condition:
            self.entities[new_key] = self.entities.pop(old_key)

    def _remove(self, key):
        return self.entities.pop(key, None)

    def _fetch(self, types=None):
        if types is None:
            types = []
        fetch_errors = []
        entities = []
        threads = []
        condition = threading.Condition()
        for service in self._all_services:
            if (len(types) == 0) or (service.name in types):
                args = {
                    'service': service,
                    'entities': entities,
                    'fetch_errors': fetch_errors,
                    'condition': condition,
                }
                thread = threading.Thread(target=self.__fetch_one, kwargs=args)
                threads.append(thread)
        [it.start() for it in threads]
        [it.join() for it in threads]
        return entities, fetch_errors

    def __fetch_one(self, service, entities, fetch_errors, condition):
        self.logger.debug('Fetching %s via %s.%s', service.plural, service.proxy, service.get_all())
        rpc = self.get_rpc()
        if service.owner:
            (code, out) = rpc.call(
                service=service.proxy,
                call=service.get_all(),
                args=[0],
            )
        else:
            (code, out) = rpc.call(
                service=service.proxy,
                call=service.get_all(),
            )
        if code == 0:
            converter = EntityConverter(self, service)
            converted = [converter.convert(it) for it in out]
            converted = [it for it in converted if it is not None]
            self.logger.debug('Fetched %d / %d %s', len(converted), len(out), service.plural)
            with condition:
                entities += converted
        else:
            self.logger.warning('Failed to fetch %s, error: %s', service.plural, out)
            with condition:
                fetch_errors.append(out)
        return code, out

    def load_from_file(self, filename: str) -> EntityT:
        self.logger.info('Load %s', filename)
        with open(filename) as fd:
            entity = json.load(fd)
        converter = EntityConverter(self, None)
        return converter.convert(entity)

    @property
    def all_entities(self):
        with self._entities_condition:
            return list(self.entities.values())

    def get_by_key(self, keys):
        """
        Get entities by key or list of keys
        """
        if keys is None or keys == 0:
            return None
        elif keys == []:
            return []
        with self._entities_condition:
            if self.entities is None:
                raise ValueError('No entities, not connected to cluster?')

            if isinstance(keys, list):
                found = [self.entities[key] for key in keys if key in self.entities]
            else:
                found = self.entities.get(keys, None)
            return found

    def get_by_name(self, name, instance_type=None):
        """
        Get the best matching entity by name over all possible types
        When instance_type is specified their is only one possible match
        """
        with self._entities_condition:
            if self.entities is None:
                raise ValueError('No entities, not connected to cluster?')
            lookup = [
                (entity.lookup(name, instance_type), entity)
                for entity in self.entities.values()
                if entity.lookup(name, instance_type) is not None
            ]
        if len(lookup) == 0:
            if instance_type is None or (
                isinstance(instance_type, str) and instance_type.lower() in ('device', 'node', 'headnode')
            ):
                if name == 'active':
                    return self.active_head_node()
                elif name == 'passive':
                    return self.passive_head_node()
            return None
        lookup.sort()
        return lookup[0][1]

    def get_by_type(
        self,
        instance_type: str | type[EntityT] | None,
        also_to_be_removed: bool = False,
    ) -> list[EntityT]:
        """
        Get all entities with the specified type
        """
        with self._entities_condition:
            if self.entities is None:
                raise ValueError('No entities, not connected to cluster?')
            found = [
                entity
                for entity in self.entities.values()
                if (
                    ((instance_type is None) or entity.check_type(instance_type))
                    and (also_to_be_removed or not entity.toBeRemoved)
                )
            ]
            return found

    def resolve_name_by_key(self, key, type_name='entity'):
        """
        Map an entity key to name.
        """
        entity = self.get_by_key(key)
        if entity is None:
            return f'unknown {type_name} with key: {key}'
        return entity.resolve_name

    def get_by_mac(self, mac: str):
        """
        Get all a device by mac.
        """
        with self._entities_condition:
            if self.entities is None:
                raise ValueError('No entities, not connected to cluster?')
            try:
                mac = mac.lower()
                return next(
                    (
                        entity
                        for entity in self.entities.values()
                        if ((e_mac := getattr(entity, 'mac', None)) is not None and e_mac.lower() == mac)
                    ),
                    None,
                )
            except Exception:
                return None

    def _entities_to_keys(self, entities: Iterable[Entity]):
        # TODO: perhaps we can do something clever here. Options are
        #       - Entity list   (works)
        #       - Key list      (works)
        #       - String list   (TODO)
        #       - Range syntax  (TODO: device only)
        return [Entity._convert_to_unique_key(it) for it in entities]

    def _process_update_removed(
        self,
        base_type,
        updated_keys,
        removed_keys,
        owner_unique_key=None,
    ):
        self.logger.info(
            "Update %d, remove %d of type %s",
            len(updated_keys),
            len(removed_keys),
            base_type,
        )
        service = self._find_service(base_type)
        code = 0
        if len(updated_keys) > 0:
            rpc = self.get_rpc()
            get_by_keys = service.get_by_keys()
            if get_by_keys is None:
                if (owner_unique_key is None) or (owner_unique_key == 0):
                    get_all = [
                        rpc.call(
                            service=service.proxy,
                            call=service.get_one(),
                            args=[it],
                        )
                        for it in updated_keys
                    ]
                else:
                    get_all = [
                        rpc.call(
                            service=service.proxy,
                            call=service.get_one(),
                            args=[owner_unique_key, it],
                        )
                        for it in updated_keys
                    ]
                code = max(it[0] for it in get_all)
                out = [it[1] for it in get_all]
            else:
                (code, out) = rpc.call(
                    service=service.proxy,
                    call=get_by_keys,
                    args=[updated_keys],
                )
            if code == RPC.OK:
                with self._entities_condition:
                    converter = EntityConverter(self, service)
                    for entity in out:
                        if 'uniqueKey' not in entity:
                            continue
                        converted = converter.convert(entity)
                        if converted is None:
                            self.logger.warning('Unable to convert entity during update')
                        else:
                            converted._resolve_keys()
                            if converted.uniqueKey in self.entities:
                                self.entities[converted.uniqueKey]._merge_updated(converted)
                                self.logger.debug('Update, merged: %s', self.entities[converted.uniqueKey].resolve_name)
                            else:
                                self.entities[converted.uniqueKey] = converted
                                self.logger.debug('Update, added: %s', self.entities[converted.uniqueKey].resolve_name)
                            self.__process_delayed_update(converted.uniqueKey)
        if len(removed_keys) > 0:
            with self._entities_condition:
                removed_keys_set = set(removed_keys)
                removed = [entity for (key, entity) in self.entities.items() if key in removed_keys_set]
                self.entities = {key: entity for (key, entity) in self.entities.items() if key not in removed_keys}
                for entity in removed:
                    entity._set_unique_keys(self, True)
                    if entity.modified:
                        self.entities[entity.uniqueKey] = entity
                        self.logger.debug('Removed, keep: %s', entity.resolve_name)
                    else:
                        entity.toBeRemoved = True
                        self.logger.debug('Removed, drop: %s', entity.resolve_name)
        self.entity_change.notify(base_type, updated_keys + removed_keys)
        if code:
            raise OSError(out)

    def _update_active_passive_head_node(self):
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='getActivePassiveKeys',
        )
        if code:
            raise OSError(out)
        self.logger.debug('Update active/passive keys: %d', len(out))
        self._active_passive_keys = out

    def active_head_node(self, force_update=False):
        """
        Get the active head node.
        """
        if self._active_passive_keys is None or force_update:
            self._update_active_passive_head_node()
        if len(self._active_passive_keys) > 0:
            return self.get_by_key(self._active_passive_keys[0])
        return None

    def passive_head_node(self, force_update=False):
        """
        Get the passive head node.
        """
        if self._active_passive_keys is None or force_update:
            self._update_active_passive_head_node()
        if len(self._active_passive_keys) > 1:
            return self.get_by_key(self._active_passive_keys[1])
        return None

    @property
    def name(self):
        """
        Get the cluster name
        """
        base_partition = self.get_base_partition()
        if base_partition is None:
            return None
        return base_partition.clusterName

    def get_base_partition(self):
        """
        Get the base partition.
        """
        return self.get_by_name('base', 'Partition')

    def version_info(self):
        """
        Get cmdaemon version information.
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='getVersion',
        )
        if code:
            raise OSError(out)
        elif out is None:
            return out
        return VersionInfo(self, out)

    def license_info(self):
        """
        Get cmdaemon license information.
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='getLicenseInfo',
        )
        if code:
            raise OSError(out)
        elif out is None:
            return out
        return LicenseInfo(self, out)

    def cluster_setup(self):
        """
        Get cmdaemon cluster setup.
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='getClusterSetup',
        )
        if code:
            raise OSError(out)
        elif out is None:
            return out
        return ClusterSetup(self, out)

    def server_status(self):
        """
        Get cmdaemon server status.
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='getServerStatus',
        )
        if code:
            raise OSError(out)
        elif out is None:
            return out
        return CMDaemonStatus(self, out)

    def overview(self):
        """
        Get cmdaemon overview.
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmgui',
            call='getClusterOverview',
        )
        if code:
            raise OSError(out)
        elif out is None:
            return out
        return GuiClusterOverview(self, out, self)

    def dns_node_mapping(self):
        """
        Get DNS server node mapping
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='getAllDnsNodeServerPairs',
        )
        if code:
            raise OSError(out)
        return TargetSourceMapping(self, out['nodes'], out['servers'])

    def dhcp_node_mapping(self):
        """
        Get DHCP server node mapping
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='getAllDhcpNodeServerPairs',
        )
        if code:
            raise OSError(out)
        return TargetSourceMapping(self, out['nodes'], out['servers'])

    def get_all_certificates(self):
        """
        Get all known certificates.
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmcert',
            call='getCertificates',
        )
        if code:
            raise OSError(out)
        return [Certificate(self, it) for it in out]

    def get_all_certificate_requests(self):
        """
        Get all current certificate requests.
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmcert',
            call='getCertificateRequests',
        )
        if code:
            raise OSError(out)
        return [CertificateRequest(self, it) for it in out]

    def get_disk_setups(self):
        """
        Get all predefined disk setup templates
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='getDiskSetups',
        )
        if code:
            raise OSError(out)
        return dict(list(zip(out['names'], out['templates'])))

    def get_raid_setups(self):
        """
        Get all predefined raid setup templates
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='getRaidSetups',
        )
        if code:
            raise OSError(out)
        return dict(list(zip(out['names'], out['templates'])))

    @property
    def new_nodes(self):
        """
        Get nodes which are booted but have no configuration.
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='getNewNodes',
        )
        if code:
            raise OSError(out)
        return [NewNode(self, it) for it in out]

    def hardware_overview(self, grouped=True):
        """
        Get the hardware overview for the nodes in the cluster
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='getHardwareOverview',
            args=[grouped],
        )
        if code:
            raise OSError(out)
        return [dict(attr_to_value.split("=", 1) for attr_to_value in item.get("list", [])) for item in out]

    @property
    def head_in_the_cloud(self):
        """
        Determine if the head node runs in the cloud
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='masterOnCloud',
        )
        if code:
            raise OSError(out)
        return out

    def report_critical_error(
        self,
        recipients=None,
        message='Critical error report from pythoncm',
        body='',
    ):
        """
        Report a critical error to all e-mail recipients.
        If none are spcecified all cluster administrators will be used.
        """
        if recipients is None:
            recipients = []
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='reportCriticalError',
            args=[recipients, message, body],
        )
        if code:
            raise OSError(out)
        return out

    def regenerate_user_certificates(self):
        """
        Regenerate all user certificates
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmuser',
            call='regenerateUserCertificates',
            args=[[]],
        )
        if code:
            raise OSError(out)
        return out.get('success', False), out.get('info', ''), out.get('errors', '')

    def register_delayed_update(self, entity, field, value):
        with self._entities_condition:
            self._delayed_updates.append((entity, field, value))

    def import_entity_from_json(self, file_name):
        """
        Import entity from a file that exists on the head node
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmmain',
            call='importEntity',
            args=[file_name, 0],
        )
        if code:
            raise OSError(out)
        return out.get('updated', False), out.get('newKey', 0), out.get('taskId', 0), out.get('validation', [])

    def merge_delayed_update(self, old_entity, updated_entity):
        with self._entities_condition:
            self._delayed_updates = [
                (entity if entity != updated_entity else old_entity, field, value)
                for entity, field, value in self._delayed_updates
            ]

    def __process_delayed_update(self, key):
        for entity, field, value in self._delayed_updates:
            if value == key:
                resolved = self.get_by_key(value)
                setattr(entity, field, resolved)
                self.logger.info(
                    'Delayed resolve %s.%s, key: %d = %s', entity.resolve_name, field, value, resolved.resolve_name
                )
        self._delayed_updates = [it for it in self._delayed_updates if it[2] != key]

    def get_all_cm_shared_paths(self):
        all_fspart = self.get_by_type(FSPart)
        return [it.path for it in all_fspart if it.type == it.meta.Type.CM_SHARED]

    def get_all_cm_node_installer_paths(self):
        all_fspart = self.get_by_type(FSPart)
        return [it.path for it in all_fspart if it.type == it.meta.Type.CM_NODE_INSTALLER]

    def get_arch_os_fspart_images(self):
        """
        Get all arch/os shared/installer image information
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmpart',
            call='getArchOSFSPartImages',
        )
        if code:
            raise OSError(out)
        info = []
        for (arch_os, head_node, shared, installer, primary_image, secondary_images) in zip(
            out.get('archOS', []),
            out.get('headNode', []),
            out.get('shared', []),
            out.get('installer', []),
            out.get('primaryImage', []),
            out.get('secondaryImages', []),
        ):
            info.append(
                {
                    'ArchOS': arch_os,
                    'head_node': head_node,
                    'shared': self.get_by_key(shared),
                    'installer': self.get_by_key(installer),
                    'primary_image': self.get_by_key(primary_image),
                    'secondary_images': [self.get_by_key(it) for it in secondary_images],
                }
            )
        return info

    def commit(
        self,
        entities: list[Entity],
        wait_for_task: bool = False,
        force: typing.SupportsInt = False,
        local_validate_check: bool = True,
        wait_for_remote_update: bool = False,
        timeout: int = 3600,
    ) -> tuple[MultiCommitResult, MultiCommitResult]:
        service = None
        entity_type = None
        add = []
        update = []
        add_check_result = []
        update_check_result = []
        for entity in entities:
            if not entity.meta.allow_commit:
                raise TypeError(f'The {entity.baseType} {entity.resolve_name} is read only and cannot be committed')
            elif not entity.meta.top_level:
                raise TypeError(f'The {entity.baseType} {entity.resolve_name} cannot be committed by itself')
            elif entity_type is None:
                service = entity._service
                entity_type = entity.baseType
            elif not entity.check_type(entity_type):
                raise TypeError(f'Entity types do not match: {entity_type}, {entity.baseType}')
            entity._set_unique_keys()
            entity._update_modified()
            if entity.uniqueKey < self.MAX_LOCAL_KEY:
                add.append(entity)
                if local_validate_check:
                    add_check_result += entity.check()
            else:
                update.append(entity)
                if local_validate_check:
                    update_check_result += entity.check()

        if bool(add):
            if wait_for_remote_update:
                self.entity_change.reset()
            old_keys = [it.uniqueKey for it in add]
            rpc = self.get_rpc()
            try:
                code, out = rpc.call(
                    service=service.proxy,
                    call=service.add_multi(),
                    args=[[it.to_dict() for it in add], int(force)],
                    timeout=timeout,
                )
                if code:
                    raise OSError(out)
                add_commit_result = MultiCommitResult(self, **out)
                add_commit_result.add(add_check_result, kind=MultiCommitResult.WARNING)
            except Exception:
                if add_check_result == []:
                    raise
                add_commit_result = MultiCommitResult(self, success=[False] * len(add))
                add_commit_result.add(add_check_result, kind=MultiCommitResult.ERROR)
            for entity, old_key, new_key in zip(add, old_keys, add_commit_result.new_keys):
                if new_key == 0:
                    self.logger.info('Failed to add: %s', entity.resolve_name)
                else:
                    entity._clear_modified()
                    entity.oldLocalUniqueKey = old_key
                    entity.uniqueKey = new_key
                    self._move_key(old_key, entity.uniqueKey)
                    self.logger.debug('Added: %s', entity.resolve_name)
            if wait_for_remote_update:
                keys = [key for key in add_commit_result.new_keys if key > 0]
                if bool(keys):
                    self.entity_change.wait(keys)
        else:
            add_commit_result = None

        if bool(update):
            if wait_for_remote_update:
                self.entity_change.reset()
            rpc = self.get_rpc()
            try:
                code, out = rpc.call(
                    service=service.proxy,
                    call=service.update_multi(),
                    args=[[it.to_dict() for it in update], int(force)],
                    timeout=timeout,
                )
                if code:
                    raise OSError(out)
                update_commit_result = MultiCommitResult(self, **out)
                update_commit_result.add(update_check_result, kind=MultiCommitResult.WARNING)
                for entity, success in zip(update, update_commit_result.success):
                    if success:
                        entity._clear_modified()
                        self.logger.debug('Updated: %s', entity.resolve_name)
                    else:
                        self.logger.info('Failed to update: %s', entity.resolve_name)
            except Exception:
                if update_check_result == []:
                    raise
                update_commit_result = MultiCommitResult(self, new_key=[0] * len(update))
                update_commit_result.add(update_check_result, kind=MultiCommitResult.ERROR)
            if wait_for_remote_update:
                keys = [entity.uniqueKey for entity, success in zip(update, update_commit_result.success) if success]
                if bool(keys):
                    self.entity_change.wait(keys)
        else:
            update_commit_result = None

        if wait_for_task:
            if add_commit_result is not None:
                add_commit_result.wait_for_task()
            if update_commit_result is not None:
                update_commit_result.wait_for_task()
        return add_commit_result, update_commit_result

    def remove(
        self,
        entities: list[Entity],
        force: typing.SupportsInt = False,
        *args,
    ) -> MultiRemoveResult:
        service = None
        entity_type = None
        remove_keys = []
        for entity in entities:
            if not entity.meta.allow_commit:
                raise TypeError(f'The {entity.baseType} {entity.resolve_name} is read only and cannot be removed')
            elif not entity.meta.top_level:
                raise TypeError(f'The {entity.baseType} {entity.resolve_name} cannot be removed by itself')
            elif entity_type is None:
                service = entity._service
                entity_type = entity.baseType
            elif not entity.check_type(entity_type):
                raise TypeError(f'Entity types do not match: {entity_type}, {entity.baseType}')
            remove_keys.append(entity.uniqueKey)
        rpc = self.get_rpc()
        rpc_args = []
        rpc_args.append(remove_keys)
        rpc_args += list(args)
        rpc_args.append(int(force))
        code, out = rpc.call(
            service=service.proxy,
            call=service.remove_multi(),
            args=rpc_args,
        )
        if code:
            raise OSError(out)
        return MultiRemoveResult(self, **out)

    def installer_interactions(self) -> list[RemoteNodeInstallerInteraction]:
        """
        Get all remote node installer interactions
        """
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='getRemoteNodeInstallerInteractions',
        )
        if code:
            raise OSError(out)
        return [RemoteNodeInstallerInteraction(self.cluster, it) for it in out]

    def file_write_info(
        self,
        nodes: str | type[EntityT] | None = None,
        path: str | list[str] | None = None,
        history: bool = False,
    ) -> list[FileWriteInfo]:
        """
        Get files that have been written
        """
        if nodes is None:
            nodes = []
        if path is None:
            path = []
        elif isinstance(path, str):
            path = [path]
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='getFileWriteInfo',
            args=[self._entities_to_keys(nodes), path, history],
        )
        if code:
            raise OSError(out)
        return [FileWriteInfo(self, it) for it in out]

    def report_file_write(
        self,
        path: str | list[str],
        frozen: bool | list[bool] | None = None,
        cm_setup: bool = True,
        node: int | Node | None = None,
    ) -> None:
        """
        Report files that have been written so cmd can keep track
        """
        if node is None:
            node = self.active_head_node().uniqueKey
        elif isinstance(node, Node):
            node = node.uniqueKey
        added = []
        for index, _filename in enumerate(path):
            info = FileWriteInfo()
            info.refNodeUniqueKey = node
            info.path = path
            info.actor = info.meta.Actor.CM_SETUP if cm_setup else info.meta.Actor.PYTHONCM
            info.timestamp = int(time.time())
            info.frozen = frozen[index] if frozen is not None and index < len(frozen) else False
            added.append(info.to_dict())
        rpc = self.get_rpc()
        (code, out) = rpc.call(
            service='cmdevice',
            call='addFileWriteInfo',
            args=[added],
        )
        if code:
            raise OSError(out)
        return out
