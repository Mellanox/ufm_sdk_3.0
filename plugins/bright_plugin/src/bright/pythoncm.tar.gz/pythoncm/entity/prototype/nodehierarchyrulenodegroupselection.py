from pythoncm.entity import NodeHierarchyRuleSelection


class NodeHierarchyRuleNodeGroupSelection(NodeHierarchyRuleSelection):
    pass
