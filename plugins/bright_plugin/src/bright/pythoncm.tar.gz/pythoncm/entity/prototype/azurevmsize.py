from pythoncm.entity import CloudType


class AzureVMSize(CloudType):
    pass
