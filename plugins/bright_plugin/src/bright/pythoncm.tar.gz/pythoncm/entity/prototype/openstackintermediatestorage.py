from pythoncm.entity import CMJobIntermediateStorage


class OpenStackIntermediateStorage(CMJobIntermediateStorage):
    pass
