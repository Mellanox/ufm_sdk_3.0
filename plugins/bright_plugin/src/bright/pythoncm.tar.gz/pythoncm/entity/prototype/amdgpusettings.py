from pythoncm.entity import GPUSettings


class AMDGPUSettings(GPUSettings):
    pass
