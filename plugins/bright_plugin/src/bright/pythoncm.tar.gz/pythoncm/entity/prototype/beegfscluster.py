from pythoncm.entity import Entity


class BeeGFSCluster(Entity):
    pass
