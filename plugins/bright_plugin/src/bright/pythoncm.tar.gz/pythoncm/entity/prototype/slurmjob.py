from pythoncm.entity import Job


class SlurmJob(Job):
    pass
