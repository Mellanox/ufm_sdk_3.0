from pythoncm.entity import Entity


class ChargeBackRequest(Entity):
    pass
