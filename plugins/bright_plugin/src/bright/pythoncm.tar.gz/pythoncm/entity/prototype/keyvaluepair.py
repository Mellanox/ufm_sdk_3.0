from pythoncm.entity import Entity


class KeyValuePair(Entity):
    pass
