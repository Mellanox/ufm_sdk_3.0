from pythoncm.entity import Entity


class FirmwareInfo(Entity):
    pass
