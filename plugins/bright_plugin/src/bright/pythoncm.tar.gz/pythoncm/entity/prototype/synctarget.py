from pythoncm.entity import Entity


class SyncTarget(Entity):
    pass
