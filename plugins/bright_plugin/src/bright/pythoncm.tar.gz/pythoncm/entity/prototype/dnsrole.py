from pythoncm.entity import Role


class DnsRole(Role):
    pass
