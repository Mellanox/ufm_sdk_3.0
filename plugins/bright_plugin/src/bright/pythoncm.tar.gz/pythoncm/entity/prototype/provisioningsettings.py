from pythoncm.entity import Entity


class ProvisioningSettings(Entity):
    pass
