from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerFabricTotal(MonitoringDataProducerInternal):
    pass
