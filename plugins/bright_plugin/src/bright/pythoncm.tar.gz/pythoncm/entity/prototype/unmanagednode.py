from pythoncm.entity import Device


class UnmanagedNode(Device):
    pass
