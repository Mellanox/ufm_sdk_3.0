from pythoncm.entity import OSCloudDisk


class OSCloudVolumeDisk(OSCloudDisk):
    pass
