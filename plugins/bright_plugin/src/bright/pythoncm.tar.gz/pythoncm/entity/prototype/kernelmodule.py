from pythoncm.entity import Entity


class KernelModule(Entity):
    pass
