from pythoncm.entity import Entity


class MonitoringJobMetricSettings(Entity):
    pass
