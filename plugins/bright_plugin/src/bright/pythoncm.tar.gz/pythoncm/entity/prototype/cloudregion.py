from pythoncm.entity import Entity


class CloudRegion(Entity):
    pass
