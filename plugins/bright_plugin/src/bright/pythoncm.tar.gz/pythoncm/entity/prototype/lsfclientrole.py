from pythoncm.entity import LSFRole


class LSFClientRole(LSFRole):
    pass
