from pythoncm.entity import Entity


class NginxReverseProxy(Entity):
    pass
