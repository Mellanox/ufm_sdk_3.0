from pythoncm.entity import Entity


class ScaleResourceProvider(Entity):
    pass
