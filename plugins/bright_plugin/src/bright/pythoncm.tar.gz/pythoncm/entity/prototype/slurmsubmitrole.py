from pythoncm.entity import WlmSubmitRole


class SlurmSubmitRole(WlmSubmitRole):
    pass
