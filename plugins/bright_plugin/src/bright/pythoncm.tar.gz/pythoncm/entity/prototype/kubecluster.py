from pythoncm.entity import Entity


class KubeCluster(Entity):
    pass
