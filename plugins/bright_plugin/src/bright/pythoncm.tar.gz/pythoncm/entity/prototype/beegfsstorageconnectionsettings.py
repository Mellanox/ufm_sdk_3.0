from pythoncm.entity import Entity


class BeeGFSStorageConnectionSettings(Entity):
    pass
