from pythoncm.entity import Entity


class SystemctlUnit(Entity):
    pass
