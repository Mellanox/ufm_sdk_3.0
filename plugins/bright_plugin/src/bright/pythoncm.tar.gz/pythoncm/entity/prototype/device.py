from pythoncm.entity import Entity


class Device(Entity):
    pass
