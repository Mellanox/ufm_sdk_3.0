from pythoncm.entity import Entity


class Partition(Entity):
    pass
