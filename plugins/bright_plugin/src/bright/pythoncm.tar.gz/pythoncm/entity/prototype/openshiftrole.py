from pythoncm.entity import Role


class OpenShiftRole(Role):
    pass
