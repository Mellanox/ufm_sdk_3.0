from pythoncm.entity import Entity


class DiskInfo(Entity):
    pass
