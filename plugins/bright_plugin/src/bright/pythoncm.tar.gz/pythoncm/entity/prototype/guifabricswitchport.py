from pythoncm.entity import Entity


class GuiFabricSwitchPort(Entity):
    pass
