from pythoncm.entity import NodeHierarchyRuleSelection


class NodeHierarchyRuleCloudRegionSelection(NodeHierarchyRuleSelection):
    pass
