from pythoncm.entity import Entity


class WlmCluster(Entity):
    pass
