from pythoncm.entity import Entity


class CustomizationEntry(Entity):
    pass
