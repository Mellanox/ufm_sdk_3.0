from pythoncm.entity import Role


class PbsProRole(Role):
    pass
