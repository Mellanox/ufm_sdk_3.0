from pythoncm.entity import CloudType


class EC2Type(CloudType):
    pass
