from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerProcMemInfo(MonitoringDataProducerInternal):
    pass
