from pythoncm.entity import MonitoringAction


class MonitoringEmailAction(MonitoringAction):
    pass
