from pythoncm.entity import Entity


class Consolidator(Entity):
    pass
