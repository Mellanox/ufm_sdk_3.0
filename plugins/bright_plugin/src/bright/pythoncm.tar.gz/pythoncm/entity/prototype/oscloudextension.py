from pythoncm.entity import Entity


class OSCloudExtension(Entity):
    pass
