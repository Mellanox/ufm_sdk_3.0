from pythoncm.entity import Entity


class GNSSLocation(Entity):
    pass
