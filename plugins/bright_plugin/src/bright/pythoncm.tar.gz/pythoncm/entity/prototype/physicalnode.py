from pythoncm.entity import ComputeNode


class PhysicalNode(ComputeNode):
    pass
