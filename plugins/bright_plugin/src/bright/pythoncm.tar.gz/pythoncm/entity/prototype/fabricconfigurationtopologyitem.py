from pythoncm.entity import Entity


class FabricConfigurationTopologyItem(Entity):
    pass
