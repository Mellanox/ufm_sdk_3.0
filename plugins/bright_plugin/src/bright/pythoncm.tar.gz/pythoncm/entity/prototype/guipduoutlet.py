from pythoncm.entity import Entity


class GuiPDUOutlet(Entity):
    pass
