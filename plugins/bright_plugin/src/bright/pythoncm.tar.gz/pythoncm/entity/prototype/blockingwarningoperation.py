from pythoncm.entity import BlockingOperation


class BlockingWarningOperation(BlockingOperation):
    pass
