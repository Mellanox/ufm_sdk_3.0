from pythoncm.entity import ScaleTracker


class ScaleKubeNamespaceTracker(ScaleTracker):
    pass
