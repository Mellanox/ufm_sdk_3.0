from pythoncm.entity import Role


class WlmSubmitRole(Role):
    pass
