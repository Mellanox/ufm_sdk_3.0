from pythoncm.entity import Entity


class BlockingOperation(Entity):
    pass
