from pythoncm.entity import Entity


class MonitoringDataProducer(Entity):
    pass
