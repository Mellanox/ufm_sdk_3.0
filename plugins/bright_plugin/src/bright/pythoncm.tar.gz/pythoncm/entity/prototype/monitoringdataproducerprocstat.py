from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerProcStat(MonitoringDataProducerInternal):
    pass
