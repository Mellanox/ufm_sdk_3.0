from pythoncm.entity import JobQueue


class GridEngineJobQueue(JobQueue):
    pass
