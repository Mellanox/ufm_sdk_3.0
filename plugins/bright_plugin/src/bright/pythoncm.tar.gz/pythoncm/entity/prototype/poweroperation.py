from pythoncm.entity import Entity


class PowerOperation(Entity):
    pass
