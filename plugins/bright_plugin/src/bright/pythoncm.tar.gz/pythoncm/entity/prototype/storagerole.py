from pythoncm.entity import Role


class StorageRole(Role):
    pass
