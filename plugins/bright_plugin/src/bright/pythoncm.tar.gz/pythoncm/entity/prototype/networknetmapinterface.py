from pythoncm.entity import NetworkInterface


class NetworkNetMapInterface(NetworkInterface):
    pass
