from pythoncm.entity import Entity


class PDUPort(Entity):
    pass
