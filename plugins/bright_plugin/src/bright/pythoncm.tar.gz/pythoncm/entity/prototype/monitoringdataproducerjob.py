from pythoncm.entity import MonitoringDataProducer


class MonitoringDataProducerJob(MonitoringDataProducer):
    pass
