from pythoncm.entity import FabricDevice


class FabricResourceBox(FabricDevice):
    pass
