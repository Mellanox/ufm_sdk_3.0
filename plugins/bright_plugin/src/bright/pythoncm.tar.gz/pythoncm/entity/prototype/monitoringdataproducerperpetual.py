from pythoncm.entity import MonitoringDataProducer


class MonitoringDataProducerPerpetual(MonitoringDataProducer):
    pass
