from pythoncm.entity import Entity


class MonitoringTrigger(Entity):
    pass
