from pythoncm.entity import BasicResource


class IPResource(BasicResource):
    pass
