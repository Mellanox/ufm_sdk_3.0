from pythoncm.entity import CMJobIntermediateStorage


class AzureIntermediateStorage(CMJobIntermediateStorage):
    pass
