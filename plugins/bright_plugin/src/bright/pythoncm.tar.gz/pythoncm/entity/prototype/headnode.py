from pythoncm.entity import Node


class HeadNode(Node):
    pass
