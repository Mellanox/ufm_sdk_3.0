from pythoncm.entity import Entity


class GuiNetworkInterface(Entity):
    pass
