from pythoncm.entity import MonitoringExecutionMultiplexer


class MonitoringLuaExecutionMultiplexer(MonitoringExecutionMultiplexer):
    pass
