from pythoncm.entity import Entity


class ContainerInfo(Entity):
    pass
