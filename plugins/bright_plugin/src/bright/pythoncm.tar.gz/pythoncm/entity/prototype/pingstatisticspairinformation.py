from pythoncm.entity import Entity


class PingStatisticsPairInformation(Entity):
    pass
