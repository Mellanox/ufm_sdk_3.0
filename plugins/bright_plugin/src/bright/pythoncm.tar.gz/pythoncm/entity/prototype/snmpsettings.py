from pythoncm.entity import Entity


class SNMPSettings(Entity):
    pass
