from pythoncm.entity import Role


class JupyterHubRole(Role):
    pass
