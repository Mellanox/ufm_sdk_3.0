from pythoncm.entity import Entity


class PingStatistics(Entity):
    pass
