from pythoncm.entity import MonitoringDataProducer


class MonitoringDataProducerScript(MonitoringDataProducer):
    pass
