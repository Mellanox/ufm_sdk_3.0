from pythoncm.entity import Entity


class ProjectManager(Entity):
    pass
