from pythoncm.entity import StatusSubSystemInfo


class StatusCollectorSubSystemInfo(StatusSubSystemInfo):
    pass
