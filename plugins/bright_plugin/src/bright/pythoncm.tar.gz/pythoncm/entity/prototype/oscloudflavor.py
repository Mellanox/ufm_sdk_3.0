from pythoncm.entity import CloudType


class OSCloudFlavor(CloudType):
    pass
