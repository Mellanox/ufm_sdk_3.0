from pythoncm.entity import Entity


class ScaleTracker(Entity):
    pass
