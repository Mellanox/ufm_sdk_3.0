from pythoncm.entity import Entity


class GuiPDUOverview(Entity):
    pass
