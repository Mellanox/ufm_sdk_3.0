from pythoncm.entity import Role


class RadosGatewayRole(Role):
    pass
