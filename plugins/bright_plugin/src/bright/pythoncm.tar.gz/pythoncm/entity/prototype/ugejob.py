from pythoncm.entity import GridEngineJob


class UGEJob(GridEngineJob):
    pass
