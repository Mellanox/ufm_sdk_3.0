from pythoncm.entity import Entity


class Package(Entity):
    pass
