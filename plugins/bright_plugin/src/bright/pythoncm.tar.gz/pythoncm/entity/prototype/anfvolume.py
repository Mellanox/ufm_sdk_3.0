from pythoncm.entity import Entity


class ANFVolume(Entity):
    pass
