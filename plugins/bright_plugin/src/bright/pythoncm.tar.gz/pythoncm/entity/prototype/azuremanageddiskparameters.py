from pythoncm.entity import Entity


class AzureManagedDiskParameters(Entity):
    pass
