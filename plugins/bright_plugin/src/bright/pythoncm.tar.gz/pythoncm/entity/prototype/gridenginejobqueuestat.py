from pythoncm.entity import JobQueueStat


class GridEngineJobQueueStat(JobQueueStat):
    pass
