from pythoncm.entity import CloudProvider


class EC2Provider(CloudProvider):
    pass
