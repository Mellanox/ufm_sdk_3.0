from pythoncm.entity import Entity


class MonitoringDeviceStateSubSystemInfo(Entity):
    pass
