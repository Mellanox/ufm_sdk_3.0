from pythoncm.entity import Entity


class PowerOperationHistory(Entity):
    pass
