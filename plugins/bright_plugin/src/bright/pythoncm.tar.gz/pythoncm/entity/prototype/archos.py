from pythoncm.entity import ArchOSInfo


class ArchOS(ArchOSInfo):
    pass
