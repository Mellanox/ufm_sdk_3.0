from pythoncm.entity import AzureDisk


class AzureDataDisk(AzureDisk):
    pass
