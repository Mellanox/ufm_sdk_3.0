from pythoncm.entity import Entity


class FirewallInterface(Entity):
    pass
