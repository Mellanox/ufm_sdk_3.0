from pythoncm.entity import Entity


class ProgramRunnerKill(Entity):
    pass
