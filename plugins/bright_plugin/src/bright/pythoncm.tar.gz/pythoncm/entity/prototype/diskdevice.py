from pythoncm.entity import Entity


class DiskDevice(Entity):
    pass
