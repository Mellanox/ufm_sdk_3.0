from pythoncm.entity import Role


class ProvisioningRole(Role):
    pass
