from pythoncm.entity import Entity


class WireguardInfo(Entity):
    pass
