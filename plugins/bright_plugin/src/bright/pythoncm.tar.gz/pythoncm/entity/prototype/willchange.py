from pythoncm.entity import Entity


class WillChange(Entity):
    pass
