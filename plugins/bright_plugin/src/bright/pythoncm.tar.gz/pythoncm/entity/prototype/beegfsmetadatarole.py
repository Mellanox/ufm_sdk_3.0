from pythoncm.entity import Role


class BeeGFSMetadataRole(Role):
    pass
