from pythoncm.entity import Entity


class FabricConfigurationTopology(Entity):
    pass
