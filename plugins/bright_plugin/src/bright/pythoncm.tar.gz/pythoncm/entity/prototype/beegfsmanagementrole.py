from pythoncm.entity import Role


class BeeGFSManagementRole(Role):
    pass
