from pythoncm.entity import SubSystemInfo


class MonitoringSubSystemInfo(SubSystemInfo):
    pass
