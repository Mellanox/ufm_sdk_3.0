from pythoncm.entity import Entity


class FPGAInfo(Entity):
    pass
