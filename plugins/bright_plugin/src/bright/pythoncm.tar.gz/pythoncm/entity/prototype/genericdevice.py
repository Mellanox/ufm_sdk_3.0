from pythoncm.entity import Device


class GenericDevice(Device):
    pass
