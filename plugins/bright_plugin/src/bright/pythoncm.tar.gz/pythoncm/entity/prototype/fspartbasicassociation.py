from pythoncm.entity import FSPartAssociation


class FSPartBasicAssociation(FSPartAssociation):
    pass
