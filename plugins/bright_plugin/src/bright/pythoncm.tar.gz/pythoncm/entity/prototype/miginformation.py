from pythoncm.entity import Entity


class MIGInformation(Entity):
    pass
