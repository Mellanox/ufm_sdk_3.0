from pythoncm.entity import Entity


class FSMount(Entity):
    pass
