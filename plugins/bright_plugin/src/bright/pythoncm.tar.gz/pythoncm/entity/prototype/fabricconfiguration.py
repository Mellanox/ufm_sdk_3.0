from pythoncm.entity import Entity


class FabricConfiguration(Entity):
    pass
