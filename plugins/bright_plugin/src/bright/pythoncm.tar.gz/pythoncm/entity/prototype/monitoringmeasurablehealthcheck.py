from pythoncm.entity import MonitoringMeasurable


class MonitoringMeasurableHealthCheck(MonitoringMeasurable):
    pass
