from pythoncm.entity import Entity


class KubeApp(Entity):
    pass
