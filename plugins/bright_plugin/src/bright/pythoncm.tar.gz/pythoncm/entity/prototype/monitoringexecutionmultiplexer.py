from pythoncm.entity import Entity


class MonitoringExecutionMultiplexer(Entity):
    pass
