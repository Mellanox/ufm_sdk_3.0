from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerTest(MonitoringDataProducerInternal):
    pass
