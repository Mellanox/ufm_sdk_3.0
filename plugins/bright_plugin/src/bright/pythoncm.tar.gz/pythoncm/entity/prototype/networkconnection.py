from pythoncm.entity import Entity


class NetworkConnection(Entity):
    pass
