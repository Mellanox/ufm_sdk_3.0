from pythoncm.entity import Entity


class LicenseInfo(Entity):
    pass
