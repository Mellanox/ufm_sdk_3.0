from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerClusterTotal(MonitoringDataProducerInternal):
    pass
