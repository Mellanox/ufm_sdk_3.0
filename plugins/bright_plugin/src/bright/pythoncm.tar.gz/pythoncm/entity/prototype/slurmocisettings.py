from pythoncm.entity import Entity


class SlurmOCISettings(Entity):
    pass
