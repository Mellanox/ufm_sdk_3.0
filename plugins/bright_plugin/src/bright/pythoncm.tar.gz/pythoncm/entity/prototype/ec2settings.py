from pythoncm.entity import CloudSettings


class EC2Settings(CloudSettings):
    pass
