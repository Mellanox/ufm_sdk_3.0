from pythoncm.entity import LSFBaseJobQueue


class LSFJobQueue(LSFBaseJobQueue):
    pass
