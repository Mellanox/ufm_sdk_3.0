from pythoncm.entity import MonitoringAction


class MonitoringDrainAction(MonitoringAction):
    pass
