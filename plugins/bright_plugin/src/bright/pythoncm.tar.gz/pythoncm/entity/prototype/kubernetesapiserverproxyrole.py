from pythoncm.entity import BaseNginxRole


class KubernetesApiServerProxyRole(BaseNginxRole):
    pass
