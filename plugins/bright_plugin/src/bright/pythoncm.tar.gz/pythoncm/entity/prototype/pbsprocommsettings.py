from pythoncm.entity import Entity


class PbsProCommSettings(Entity):
    pass
