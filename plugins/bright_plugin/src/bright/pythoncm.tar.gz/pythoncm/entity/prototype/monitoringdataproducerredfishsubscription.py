from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerRedFishSubscription(MonitoringDataProducerInternal):
    pass
