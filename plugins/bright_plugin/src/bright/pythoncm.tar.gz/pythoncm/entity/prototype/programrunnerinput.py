from pythoncm.entity import Entity


class ProgramRunnerInput(Entity):
    pass
