from pythoncm.entity import Entity


class PbsProMomSettings(Entity):
    pass
