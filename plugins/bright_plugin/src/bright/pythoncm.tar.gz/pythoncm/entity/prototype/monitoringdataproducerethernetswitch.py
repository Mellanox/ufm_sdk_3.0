from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerEthernetSwitch(MonitoringDataProducerInternal):
    pass
