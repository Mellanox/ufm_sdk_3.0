from pythoncm.entity import GridEngineParallelEnvironment


class UGEParallelEnvironment(GridEngineParallelEnvironment):
    pass
