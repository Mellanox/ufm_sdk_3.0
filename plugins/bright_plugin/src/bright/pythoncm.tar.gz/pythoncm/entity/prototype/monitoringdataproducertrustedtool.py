from pythoncm.entity import MonitoringDataProducer


class MonitoringDataProducerTrustedTool(MonitoringDataProducer):
    pass
