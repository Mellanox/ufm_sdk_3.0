from pythoncm.entity import Role


class DIGITSRole(Role):
    pass
