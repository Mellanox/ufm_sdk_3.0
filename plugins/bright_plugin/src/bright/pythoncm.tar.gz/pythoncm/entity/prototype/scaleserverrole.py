from pythoncm.entity import Role


class ScaleServerRole(Role):
    pass
