from pythoncm.entity import Role


class SubnetManagerRole(Role):
    pass
