from pythoncm.entity import BasicResource


class GenericResource(BasicResource):
    pass
