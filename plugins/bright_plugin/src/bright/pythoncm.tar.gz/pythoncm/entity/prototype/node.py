from pythoncm.entity import Device


class Node(Device):
    pass
