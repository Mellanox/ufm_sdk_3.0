from pythoncm.entity import Entity


class EC2VPC(Entity):
    pass
