from pythoncm.entity import Entity


class ExcludeListSnippet(Entity):
    pass
