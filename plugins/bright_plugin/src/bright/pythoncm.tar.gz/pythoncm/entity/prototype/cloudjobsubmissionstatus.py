from pythoncm.entity import Entity


class CloudJobSubmissionStatus(Entity):
    pass
