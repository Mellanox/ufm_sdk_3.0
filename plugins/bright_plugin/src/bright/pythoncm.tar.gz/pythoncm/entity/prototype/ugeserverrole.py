from pythoncm.entity import UGERole


class UGEServerRole(UGERole):
    pass
