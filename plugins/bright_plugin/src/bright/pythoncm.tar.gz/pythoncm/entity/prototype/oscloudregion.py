from pythoncm.entity import CloudRegion


class OSCloudRegion(CloudRegion):
    pass
