from pythoncm.entity import Entity


class DiskSetup(Entity):
    pass
