from pythoncm.entity import Entity


class ProvisioningRequestStatus(Entity):
    pass
