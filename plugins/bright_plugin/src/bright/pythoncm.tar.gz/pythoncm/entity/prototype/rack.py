from pythoncm.entity import Entity


class Rack(Entity):
    pass
