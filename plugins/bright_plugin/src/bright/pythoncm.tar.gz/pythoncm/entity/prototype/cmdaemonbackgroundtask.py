from pythoncm.entity import Entity


class CMDaemonBackgroundTask(Entity):
    pass
