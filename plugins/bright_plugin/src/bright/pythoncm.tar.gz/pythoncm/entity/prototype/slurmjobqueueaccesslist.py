from pythoncm.entity import Entity


class SlurmJobQueueAccessList(Entity):
    pass
