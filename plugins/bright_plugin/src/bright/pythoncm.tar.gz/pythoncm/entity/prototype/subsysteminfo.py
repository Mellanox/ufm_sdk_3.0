from pythoncm.entity import Entity


class SubSystemInfo(Entity):
    pass
