from pythoncm.entity import Role


class BaseNginxRole(Role):
    pass
