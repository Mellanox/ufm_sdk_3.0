from pythoncm.entity import Entity


class EdgeSite(Entity):
    pass
