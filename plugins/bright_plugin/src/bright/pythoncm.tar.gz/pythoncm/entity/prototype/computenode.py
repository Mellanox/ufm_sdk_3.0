from pythoncm.entity import Node


class ComputeNode(Node):
    pass
