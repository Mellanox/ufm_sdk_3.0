from pythoncm.entity import MonitoringExecutionMultiplexer


class MonitoringOverlayListExecutionMultiplexer(MonitoringExecutionMultiplexer):
    pass
