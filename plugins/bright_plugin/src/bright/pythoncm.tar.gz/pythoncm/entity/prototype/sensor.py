from pythoncm.entity import Entity


class Sensor(Entity):
    pass
