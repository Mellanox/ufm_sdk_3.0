from pythoncm.entity import Entity


class RackPosition(Entity):
    pass
