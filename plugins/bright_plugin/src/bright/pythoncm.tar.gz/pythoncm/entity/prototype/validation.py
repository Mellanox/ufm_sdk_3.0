from pythoncm.entity import Entity


class Validation(Entity):
    pass
