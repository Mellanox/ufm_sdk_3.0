from pythoncm.entity import Role


class FirewallRole(Role):
    pass
