from pythoncm.entity import Entity


class JobQueueStat(Entity):
    pass
