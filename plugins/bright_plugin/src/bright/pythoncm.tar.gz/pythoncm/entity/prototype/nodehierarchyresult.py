from pythoncm.entity import Entity


class NodeHierarchyResult(Entity):
    pass
