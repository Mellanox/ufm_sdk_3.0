from pythoncm.entity import Entity


class GuiNodeStatus(Entity):
    pass
