from pythoncm.entity import Entity


class JobInfoStatistics(Entity):
    pass
