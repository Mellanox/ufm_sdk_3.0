from pythoncm.entity import CMJobIntermediateStorage


class AWSIntermediateStorage(CMJobIntermediateStorage):
    pass
