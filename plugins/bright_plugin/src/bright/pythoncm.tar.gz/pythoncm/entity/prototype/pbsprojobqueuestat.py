from pythoncm.entity import PBSJobQueueStat


class PbsProJobQueueStat(PBSJobQueueStat):
    pass
