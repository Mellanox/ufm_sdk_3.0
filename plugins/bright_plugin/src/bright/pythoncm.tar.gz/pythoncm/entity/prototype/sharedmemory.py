from pythoncm.entity import Entity


class SharedMemory(Entity):
    pass
