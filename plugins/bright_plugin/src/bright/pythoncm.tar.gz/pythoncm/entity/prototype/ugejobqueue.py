from pythoncm.entity import GridEngineJobQueue


class UGEJobQueue(GridEngineJobQueue):
    pass
