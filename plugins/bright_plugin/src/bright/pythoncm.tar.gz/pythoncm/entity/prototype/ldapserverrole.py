from pythoncm.entity import Role


class LdapServerRole(Role):
    pass
