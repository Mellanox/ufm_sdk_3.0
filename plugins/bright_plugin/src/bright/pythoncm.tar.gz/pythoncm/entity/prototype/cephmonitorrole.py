from pythoncm.entity import Role


class CephMonitorRole(Role):
    pass
