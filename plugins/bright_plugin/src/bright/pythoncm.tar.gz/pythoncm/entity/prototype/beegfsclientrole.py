from pythoncm.entity import Role


class BeeGFSClientRole(Role):
    pass
