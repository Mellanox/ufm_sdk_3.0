from pythoncm.entity import CloudProvider


class OSCloudProvider(CloudProvider):
    pass
