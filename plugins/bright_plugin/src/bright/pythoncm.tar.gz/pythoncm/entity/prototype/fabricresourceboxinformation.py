from pythoncm.entity import Entity


class FabricResourceBoxInformation(Entity):
    pass
