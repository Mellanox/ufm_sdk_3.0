from pythoncm.entity import UGERole


class UGEClientRole(UGERole):
    pass
