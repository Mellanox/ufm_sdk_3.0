from pythoncm.entity import Entity


class MonitoringDataCacheSubSystemInfo(Entity):
    pass
