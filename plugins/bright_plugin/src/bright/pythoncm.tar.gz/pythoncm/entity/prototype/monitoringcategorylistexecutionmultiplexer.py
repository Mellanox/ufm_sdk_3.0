from pythoncm.entity import MonitoringExecutionMultiplexer


class MonitoringCategoryListExecutionMultiplexer(MonitoringExecutionMultiplexer):
    pass
