from pythoncm.entity import Entity


class SysInfoCollector(Entity):
    pass
