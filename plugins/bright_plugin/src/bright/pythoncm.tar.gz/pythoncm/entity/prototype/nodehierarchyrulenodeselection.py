from pythoncm.entity import NodeHierarchyRuleSelection


class NodeHierarchyRuleNodeSelection(NodeHierarchyRuleSelection):
    pass
