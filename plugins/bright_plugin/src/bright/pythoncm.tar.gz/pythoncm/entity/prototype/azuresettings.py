from pythoncm.entity import CloudSettings


class AzureSettings(CloudSettings):
    pass
