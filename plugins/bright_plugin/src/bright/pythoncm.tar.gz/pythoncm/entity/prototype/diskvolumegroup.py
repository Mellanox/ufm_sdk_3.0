from pythoncm.entity import Entity


class DiskVolumeGroup(Entity):
    pass
