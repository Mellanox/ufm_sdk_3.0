from pythoncm.entity import Entity


class DrainResult(Entity):
    pass
