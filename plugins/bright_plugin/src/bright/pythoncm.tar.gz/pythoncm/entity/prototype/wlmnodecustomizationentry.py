from pythoncm.entity import Entity


class WlmNodeCustomizationEntry(Entity):
    pass
