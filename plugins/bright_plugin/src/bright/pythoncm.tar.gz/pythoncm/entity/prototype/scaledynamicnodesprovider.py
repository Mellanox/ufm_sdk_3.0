from pythoncm.entity import ScaleResourceProvider


class ScaleDynamicNodesProvider(ScaleResourceProvider):
    pass
