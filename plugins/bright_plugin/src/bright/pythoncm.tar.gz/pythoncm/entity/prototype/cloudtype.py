from pythoncm.entity import Entity


class CloudType(Entity):
    pass
