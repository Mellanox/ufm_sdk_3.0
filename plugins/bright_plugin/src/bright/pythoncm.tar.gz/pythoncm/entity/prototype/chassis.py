from pythoncm.entity import Device


class Chassis(Device):
    pass
