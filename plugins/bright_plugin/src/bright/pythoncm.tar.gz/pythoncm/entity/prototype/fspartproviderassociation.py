from pythoncm.entity import FSPartAssociation


class FSPartProviderAssociation(FSPartAssociation):
    pass
