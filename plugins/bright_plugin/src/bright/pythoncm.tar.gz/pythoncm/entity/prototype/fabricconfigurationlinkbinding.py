from pythoncm.entity import FabricConfigurationBinding


class FabricConfigurationLinkBinding(FabricConfigurationBinding):
    pass
