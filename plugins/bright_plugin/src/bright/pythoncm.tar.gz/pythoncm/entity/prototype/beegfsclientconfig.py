from pythoncm.entity import Entity


class BeeGFSClientConfig(Entity):
    pass
