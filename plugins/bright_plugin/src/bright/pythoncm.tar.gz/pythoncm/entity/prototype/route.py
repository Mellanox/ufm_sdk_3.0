from pythoncm.entity import Entity


class Route(Entity):
    pass
