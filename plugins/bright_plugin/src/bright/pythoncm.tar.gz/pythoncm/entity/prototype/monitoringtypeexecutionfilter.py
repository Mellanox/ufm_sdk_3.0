from pythoncm.entity import MonitoringExecutionFilter


class MonitoringTypeExecutionFilter(MonitoringExecutionFilter):
    pass
