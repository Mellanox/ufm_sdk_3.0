from pythoncm.entity import Entity


class KubePodController(Entity):
    pass
