from pythoncm.entity import FabricConfigurationTopologyDevice


class FabricConfigurationTopologyDSP(FabricConfigurationTopologyDevice):
    pass
