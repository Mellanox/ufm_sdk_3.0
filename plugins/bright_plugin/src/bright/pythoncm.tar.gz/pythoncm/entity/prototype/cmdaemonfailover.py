from pythoncm.entity import Entity


class CMDaemonFailover(Entity):
    pass
