from pythoncm.entity import Entity


class CephState(Entity):
    pass
