from pythoncm.entity import LSFBaseJob


class LSFJob(LSFBaseJob):
    pass
