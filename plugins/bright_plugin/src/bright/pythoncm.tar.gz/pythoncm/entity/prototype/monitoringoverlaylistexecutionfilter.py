from pythoncm.entity import MonitoringExecutionFilter


class MonitoringOverlayListExecutionFilter(MonitoringExecutionFilter):
    pass
