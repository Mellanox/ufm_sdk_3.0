from pythoncm.entity import Entity


class BeeGFSMetadataConnectionSettings(Entity):
    pass
