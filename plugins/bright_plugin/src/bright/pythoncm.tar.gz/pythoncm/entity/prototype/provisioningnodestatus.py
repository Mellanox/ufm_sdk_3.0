from pythoncm.entity import Entity


class ProvisioningNodeStatus(Entity):
    pass
