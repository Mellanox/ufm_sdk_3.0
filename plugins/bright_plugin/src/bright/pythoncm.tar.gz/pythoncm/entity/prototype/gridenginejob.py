from pythoncm.entity import Job


class GridEngineJob(Job):
    pass
