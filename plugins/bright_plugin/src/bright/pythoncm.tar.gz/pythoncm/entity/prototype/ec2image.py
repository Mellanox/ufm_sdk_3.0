from pythoncm.entity import Entity


class EC2Image(Entity):
    pass
