from pythoncm.entity import Entity


class Profile(Entity):
    pass
