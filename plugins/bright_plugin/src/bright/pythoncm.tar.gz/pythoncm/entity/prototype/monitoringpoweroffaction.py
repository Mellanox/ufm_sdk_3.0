from pythoncm.entity import MonitoringPowerAction


class MonitoringPowerOffAction(MonitoringPowerAction):
    pass
