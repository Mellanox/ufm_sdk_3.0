from pythoncm.entity import OpenShiftRole


class OpenShiftWorkerRole(OpenShiftRole):
    pass
