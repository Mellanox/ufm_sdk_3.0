from pythoncm.entity import BaseNginxRole


class OpenShiftProxyRole(BaseNginxRole):
    pass
