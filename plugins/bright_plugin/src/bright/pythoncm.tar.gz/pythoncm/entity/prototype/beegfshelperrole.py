from pythoncm.entity import Role


class BeeGFSHelperRole(Role):
    pass
