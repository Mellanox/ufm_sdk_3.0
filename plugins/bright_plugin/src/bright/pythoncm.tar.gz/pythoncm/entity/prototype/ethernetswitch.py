from pythoncm.entity import Switch


class EthernetSwitch(Switch):
    pass
