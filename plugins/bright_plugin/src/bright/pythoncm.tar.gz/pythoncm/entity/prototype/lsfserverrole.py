from pythoncm.entity import LSFRole


class LSFServerRole(LSFRole):
    pass
