from pythoncm.entity import FabricConfigurationBinding


class FabricConfigurationHostBinding(FabricConfigurationBinding):
    pass
