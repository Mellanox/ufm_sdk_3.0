from pythoncm.entity import Entity


class BeeGFSManagementConfig(Entity):
    pass
