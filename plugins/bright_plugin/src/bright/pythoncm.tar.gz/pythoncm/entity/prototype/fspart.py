from pythoncm.entity import Entity


class FSPart(Entity):
    pass
