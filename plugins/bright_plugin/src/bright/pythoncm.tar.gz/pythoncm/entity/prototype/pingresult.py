from pythoncm.entity import Entity


class PingResult(Entity):
    pass
