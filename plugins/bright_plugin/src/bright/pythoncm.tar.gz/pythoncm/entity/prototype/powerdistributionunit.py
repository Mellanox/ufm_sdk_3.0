from pythoncm.entity import Device


class PowerDistributionUnit(Device):
    pass
