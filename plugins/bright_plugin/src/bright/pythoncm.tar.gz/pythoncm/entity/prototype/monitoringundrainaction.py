from pythoncm.entity import MonitoringAction


class MonitoringUndrainAction(MonitoringAction):
    pass
