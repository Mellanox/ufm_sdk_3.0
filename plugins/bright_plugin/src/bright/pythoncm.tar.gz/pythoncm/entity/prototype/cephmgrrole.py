from pythoncm.entity import Role


class CephMGRRole(Role):
    pass
