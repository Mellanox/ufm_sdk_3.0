from pythoncm.entity import Entity


class ScaleAdvancedSettings(Entity):
    pass
