from pythoncm.entity import Entity


class RemoteNodeInstallerInteraction(Entity):
    pass
