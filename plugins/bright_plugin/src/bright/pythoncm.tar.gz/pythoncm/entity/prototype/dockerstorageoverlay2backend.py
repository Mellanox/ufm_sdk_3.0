from pythoncm.entity import DockerStorageBackend


class DockerStorageOverlay2Backend(DockerStorageBackend):
    pass
