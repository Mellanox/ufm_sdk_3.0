from pythoncm.entity import OSCloudDisk


class OSCloudEphemeralDisk(OSCloudDisk):
    pass
