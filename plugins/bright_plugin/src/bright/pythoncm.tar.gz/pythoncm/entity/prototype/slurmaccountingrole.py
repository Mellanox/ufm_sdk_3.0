from pythoncm.entity import Role


class SlurmAccountingRole(Role):
    pass
