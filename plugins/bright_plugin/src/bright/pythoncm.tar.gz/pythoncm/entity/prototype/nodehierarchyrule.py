from pythoncm.entity import Entity


class NodeHierarchyRule(Entity):
    pass
