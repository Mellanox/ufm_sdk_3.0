from pythoncm.entity import CloudRegion


class AzureLocation(CloudRegion):
    pass
