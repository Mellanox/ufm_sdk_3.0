from pythoncm.entity import WlmCgroupsSettings


class PbsProCgroupsSettings(WlmCgroupsSettings):
    pass
