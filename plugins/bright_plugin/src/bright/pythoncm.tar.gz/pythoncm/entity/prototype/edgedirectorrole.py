from pythoncm.entity import DirectorRole


class EdgeDirectorRole(DirectorRole):
    pass
