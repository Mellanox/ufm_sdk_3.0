from pythoncm.entity import Entity


class KubeUser(Entity):
    pass
