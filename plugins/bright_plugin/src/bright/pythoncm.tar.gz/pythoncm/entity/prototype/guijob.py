from pythoncm.entity import Entity


class GuiJob(Entity):
    pass
