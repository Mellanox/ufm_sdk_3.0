from pythoncm.entity import GenericRoleConfiguration


class GenericRoleTemplatedConfiguration(GenericRoleConfiguration):
    pass
