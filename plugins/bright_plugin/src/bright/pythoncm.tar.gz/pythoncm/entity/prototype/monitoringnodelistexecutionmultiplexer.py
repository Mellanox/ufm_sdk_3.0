from pythoncm.entity import MonitoringExecutionMultiplexer


class MonitoringNodeListExecutionMultiplexer(MonitoringExecutionMultiplexer):
    pass
