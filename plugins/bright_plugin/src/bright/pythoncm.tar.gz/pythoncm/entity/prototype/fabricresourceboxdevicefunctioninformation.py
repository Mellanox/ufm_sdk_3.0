from pythoncm.entity import Entity


class FabricResourceBoxDeviceFunctionInformation(Entity):
    pass
