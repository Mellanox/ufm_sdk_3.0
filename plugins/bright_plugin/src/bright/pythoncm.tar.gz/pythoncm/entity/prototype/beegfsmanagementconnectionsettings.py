from pythoncm.entity import Entity


class BeeGFSManagementConnectionSettings(Entity):
    pass
