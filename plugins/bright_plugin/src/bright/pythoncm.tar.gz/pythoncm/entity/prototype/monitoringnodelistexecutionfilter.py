from pythoncm.entity import MonitoringExecutionFilter


class MonitoringNodeListExecutionFilter(MonitoringExecutionFilter):
    pass
