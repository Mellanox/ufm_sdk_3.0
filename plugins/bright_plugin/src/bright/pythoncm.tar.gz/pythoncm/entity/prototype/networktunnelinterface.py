from pythoncm.entity import NetworkInterface


class NetworkTunnelInterface(NetworkInterface):
    pass
