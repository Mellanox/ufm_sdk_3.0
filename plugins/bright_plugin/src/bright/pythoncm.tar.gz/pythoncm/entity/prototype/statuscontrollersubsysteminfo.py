from pythoncm.entity import StatusSubSystemInfo


class StatusControllerSubSystemInfo(StatusSubSystemInfo):
    pass
