from pythoncm.entity import Entity


class GuiFabricSwitchLed(Entity):
    pass
