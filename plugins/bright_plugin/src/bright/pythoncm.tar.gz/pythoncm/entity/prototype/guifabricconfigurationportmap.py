from pythoncm.entity import Entity


class GuiFabricConfigurationPortmap(Entity):
    pass
