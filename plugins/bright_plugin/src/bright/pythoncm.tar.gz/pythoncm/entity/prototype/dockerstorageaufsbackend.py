from pythoncm.entity import DockerStorageBackend


class DockerStorageAufsBackend(DockerStorageBackend):
    pass
