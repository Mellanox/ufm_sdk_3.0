from pythoncm.entity import Entity


class GuiNodeOverview(Entity):
    pass
