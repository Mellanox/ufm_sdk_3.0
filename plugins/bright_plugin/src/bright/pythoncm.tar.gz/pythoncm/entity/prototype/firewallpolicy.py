from pythoncm.entity import Entity


class FirewallPolicy(Entity):
    pass
