from pythoncm.entity import Role


class UGERole(Role):
    pass
