from pythoncm.entity import Entity


class CMDaemonFailoverPeer(Entity):
    pass
