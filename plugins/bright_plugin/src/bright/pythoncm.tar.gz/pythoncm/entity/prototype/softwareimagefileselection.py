from pythoncm.entity import Entity


class SoftwareImageFileSelection(Entity):
    pass
