from pythoncm.entity import Entity


class Session(Entity):
    pass
