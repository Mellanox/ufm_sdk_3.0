from pythoncm.entity import Entity


class MonitoringStorageSubSystemInfo(Entity):
    pass
