from pythoncm.entity import Entity


class MsgQueue(Entity):
    pass
