from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerRackSensor(MonitoringDataProducerInternal):
    pass
