from pythoncm.entity import Role


class SnmpTrapRole(Role):
    pass
