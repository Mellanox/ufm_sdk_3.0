from pythoncm.entity import Entity


class FirewallOpenPort(Entity):
    pass
