from pythoncm.entity import FabricConfigurationTopologyItem


class FabricConfigurationTopologyDevice(FabricConfigurationTopologyItem):
    pass
