from pythoncm.entity import Entity


class CertificateSubjectName(Entity):
    pass
