from pythoncm.entity import NetworkInterface


class NetworkPhysicalInterface(NetworkInterface):
    pass
