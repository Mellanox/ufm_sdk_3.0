from pythoncm.entity import Entity


class Group(Entity):
    pass
