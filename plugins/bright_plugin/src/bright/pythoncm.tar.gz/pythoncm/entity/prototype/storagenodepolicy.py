from pythoncm.entity import Entity


class StorageNodePolicy(Entity):
    pass
