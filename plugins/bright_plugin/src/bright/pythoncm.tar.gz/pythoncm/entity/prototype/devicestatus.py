from pythoncm.entity import Entity


class DeviceStatus(Entity):
    pass
