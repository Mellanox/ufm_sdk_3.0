from pythoncm.entity import Entity


class NodeGroup(Entity):
    pass
