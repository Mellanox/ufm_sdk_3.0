from pythoncm.entity import MonitoringAction


class MonitoringPowerAction(MonitoringAction):
    pass
