from pythoncm.entity import Entity


class ResourcePoolStatus(Entity):
    pass
