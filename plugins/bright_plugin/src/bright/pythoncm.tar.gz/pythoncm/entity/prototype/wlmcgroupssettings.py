from pythoncm.entity import Entity


class WlmCgroupsSettings(Entity):
    pass
