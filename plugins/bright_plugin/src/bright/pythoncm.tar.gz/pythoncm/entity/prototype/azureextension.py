from pythoncm.entity import Entity


class AzureExtension(Entity):
    pass
