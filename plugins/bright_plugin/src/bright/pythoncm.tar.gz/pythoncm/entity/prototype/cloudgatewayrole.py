from pythoncm.entity import Role


class CloudGatewayRole(Role):
    pass
