from pythoncm.entity import Entity


class PrometheusQuery(Entity):
    pass
