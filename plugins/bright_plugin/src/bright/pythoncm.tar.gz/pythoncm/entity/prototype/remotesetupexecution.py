from pythoncm.entity import Entity


class RemoteSetupExecution(Entity):
    pass
