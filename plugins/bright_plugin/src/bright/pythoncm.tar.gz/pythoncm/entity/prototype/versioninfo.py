from pythoncm.entity import Entity


class VersionInfo(Entity):
    pass
