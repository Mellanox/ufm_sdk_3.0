from pythoncm.entity import StatusSubSystemInfo


class StatusManagerSubSystemInfo(StatusSubSystemInfo):
    pass
