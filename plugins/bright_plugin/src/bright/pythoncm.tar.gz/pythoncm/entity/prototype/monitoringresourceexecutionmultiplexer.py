from pythoncm.entity import MonitoringExecutionMultiplexer


class MonitoringResourceExecutionMultiplexer(MonitoringExecutionMultiplexer):
    pass
