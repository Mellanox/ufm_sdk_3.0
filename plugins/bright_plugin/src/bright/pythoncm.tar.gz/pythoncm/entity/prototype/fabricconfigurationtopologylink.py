from pythoncm.entity import FabricConfigurationTopologyItem


class FabricConfigurationTopologyLink(FabricConfigurationTopologyItem):
    pass
