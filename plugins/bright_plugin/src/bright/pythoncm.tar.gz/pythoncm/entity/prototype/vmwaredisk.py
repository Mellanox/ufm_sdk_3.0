from pythoncm.entity import Entity


class VMWareDisk(Entity):
    pass
