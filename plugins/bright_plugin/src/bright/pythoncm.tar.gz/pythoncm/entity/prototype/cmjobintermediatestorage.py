from pythoncm.entity import Entity


class CMJobIntermediateStorage(Entity):
    pass
