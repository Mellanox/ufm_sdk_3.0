from pythoncm.entity import Entity


class CertificateRequest(Entity):
    pass
