from pythoncm.entity import MonitoringExecutionMultiplexer


class MonitoringTypeExecutionMultiplexer(MonitoringExecutionMultiplexer):
    pass
