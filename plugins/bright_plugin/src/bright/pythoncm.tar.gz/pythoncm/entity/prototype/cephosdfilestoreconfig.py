from pythoncm.entity import CephOSDConfig


class CephOSDFileStoreConfig(CephOSDConfig):
    pass
