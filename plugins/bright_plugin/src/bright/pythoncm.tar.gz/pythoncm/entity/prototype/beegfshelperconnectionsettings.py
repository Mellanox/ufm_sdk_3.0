from pythoncm.entity import Entity


class BeeGFSHelperConnectionSettings(Entity):
    pass
