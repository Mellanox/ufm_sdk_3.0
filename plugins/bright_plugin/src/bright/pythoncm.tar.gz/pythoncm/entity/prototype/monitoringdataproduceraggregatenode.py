from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerAggregateNode(MonitoringDataProducerInternal):
    pass
