from pythoncm.entity import Entity


class FSPartInfo(Entity):
    pass
