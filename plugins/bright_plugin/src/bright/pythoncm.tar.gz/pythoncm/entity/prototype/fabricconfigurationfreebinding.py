from pythoncm.entity import FabricConfigurationBinding


class FabricConfigurationFreeBinding(FabricConfigurationBinding):
    pass
