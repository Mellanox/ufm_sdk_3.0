from pythoncm.entity import Entity


class CephOSDConfig(Entity):
    pass
