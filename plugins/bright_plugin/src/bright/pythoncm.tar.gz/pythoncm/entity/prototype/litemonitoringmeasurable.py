from pythoncm.entity import Entity


class LiteMonitoringMeasurable(Entity):
    pass
