from pythoncm.entity import Entity


class SyncInfo(Entity):
    pass
