from pythoncm.entity import Entity


class SELinuxSettings(Entity):
    pass
