from pythoncm.entity import Entity


class EtcdCluster(Entity):
    pass
