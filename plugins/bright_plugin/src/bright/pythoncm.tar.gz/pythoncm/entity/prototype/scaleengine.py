from pythoncm.entity import Entity


class ScaleEngine(Entity):
    pass
