from pythoncm.entity import MonitoringDataProducer


class MonitoringDataProducerInternal(MonitoringDataProducer):
    pass
