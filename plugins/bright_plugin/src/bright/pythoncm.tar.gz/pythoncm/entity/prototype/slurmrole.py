from pythoncm.entity import Role


class SlurmRole(Role):
    pass
