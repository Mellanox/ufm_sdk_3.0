from pythoncm.entity import WlmSubmitRole


class UGESubmitRole(WlmSubmitRole):
    pass
