from pythoncm.entity import Entity


class MemoryInfo(Entity):
    pass
