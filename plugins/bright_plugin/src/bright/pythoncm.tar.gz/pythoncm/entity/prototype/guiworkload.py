from pythoncm.entity import Entity


class GuiWorkload(Entity):
    pass
