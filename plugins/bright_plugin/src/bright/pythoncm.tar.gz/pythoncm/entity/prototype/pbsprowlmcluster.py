from pythoncm.entity import WlmCluster


class PbsProWlmCluster(WlmCluster):
    pass
