from pythoncm.entity import Entity


class PingStatisticsGlobalInformation(Entity):
    pass
