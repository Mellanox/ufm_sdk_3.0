from pythoncm.entity import JobQueueStat


class SlurmJobQueueStat(JobQueueStat):
    pass
