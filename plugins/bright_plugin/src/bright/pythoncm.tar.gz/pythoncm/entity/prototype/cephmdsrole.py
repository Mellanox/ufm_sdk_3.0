from pythoncm.entity import Role


class CephMDSRole(Role):
    pass
