from pythoncm.entity import Entity


class PbsPelog(Entity):
    pass
