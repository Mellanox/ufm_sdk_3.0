from pythoncm.entity import ComputeNode


class CloudNode(ComputeNode):
    pass
