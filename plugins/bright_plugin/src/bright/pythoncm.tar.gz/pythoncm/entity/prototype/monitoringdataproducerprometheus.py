from pythoncm.entity import MonitoringDataProducer


class MonitoringDataProducerPrometheus(MonitoringDataProducer):
    pass
