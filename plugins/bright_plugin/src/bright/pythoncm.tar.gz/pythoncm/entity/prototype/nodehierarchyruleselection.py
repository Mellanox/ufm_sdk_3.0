from pythoncm.entity import Entity


class NodeHierarchyRuleSelection(Entity):
    pass
