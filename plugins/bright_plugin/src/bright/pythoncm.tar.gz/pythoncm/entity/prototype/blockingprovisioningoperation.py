from pythoncm.entity import BlockingOperation


class BlockingProvisioningOperation(BlockingOperation):
    pass
