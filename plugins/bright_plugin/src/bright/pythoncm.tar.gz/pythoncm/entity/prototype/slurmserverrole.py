from pythoncm.entity import SlurmRole


class SlurmServerRole(SlurmRole):
    pass
