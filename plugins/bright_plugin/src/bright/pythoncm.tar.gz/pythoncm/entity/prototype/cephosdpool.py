from pythoncm.entity import Entity


class CephOSDPool(Entity):
    pass
