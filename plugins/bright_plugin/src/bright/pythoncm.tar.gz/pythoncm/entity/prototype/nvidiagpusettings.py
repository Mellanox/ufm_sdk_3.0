from pythoncm.entity import GPUSettings


class NvidiaGPUSettings(GPUSettings):
    pass
