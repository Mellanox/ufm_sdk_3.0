from pythoncm.entity import Entity


class GPUProfilingMetricInfo(Entity):
    pass
