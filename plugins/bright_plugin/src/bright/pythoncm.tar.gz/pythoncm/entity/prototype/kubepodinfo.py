from pythoncm.entity import Entity


class KubePodInfo(Entity):
    pass
