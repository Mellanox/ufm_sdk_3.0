from pythoncm.entity import MonitoringDataProducer


class MonitoringDataProducerLua(MonitoringDataProducer):
    pass
