from pythoncm.entity import Entity


class SyncSource(Entity):
    pass
