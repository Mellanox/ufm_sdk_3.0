from pythoncm.entity import JobQueueStat


class PBSJobQueueStat(JobQueueStat):
    pass
