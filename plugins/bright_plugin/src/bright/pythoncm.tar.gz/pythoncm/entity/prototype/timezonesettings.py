from pythoncm.entity import Entity


class TimeZoneSettings(Entity):
    pass
