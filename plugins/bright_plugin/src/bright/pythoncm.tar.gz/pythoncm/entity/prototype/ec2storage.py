from pythoncm.entity import Entity


class EC2Storage(Entity):
    pass
