from pythoncm.entity import NetworkInterface


class NetworkBridgeInterface(NetworkInterface):
    pass
