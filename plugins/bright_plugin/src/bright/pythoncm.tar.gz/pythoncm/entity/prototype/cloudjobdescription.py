from pythoncm.entity import Entity


class CloudJobDescription(Entity):
    pass
