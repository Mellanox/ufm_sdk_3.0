from pythoncm.entity import Entity


class FSPartAssociation(Entity):
    pass
