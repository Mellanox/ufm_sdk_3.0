from pythoncm.entity import NodeHierarchyRuleSelection


class NodeHierarchyRuleRackSelection(NodeHierarchyRuleSelection):
    pass
