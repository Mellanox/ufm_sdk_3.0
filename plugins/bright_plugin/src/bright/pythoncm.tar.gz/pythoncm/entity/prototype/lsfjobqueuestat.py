from pythoncm.entity import LSFBaseJobQueueStat


class LSFJobQueueStat(LSFBaseJobQueueStat):
    pass
