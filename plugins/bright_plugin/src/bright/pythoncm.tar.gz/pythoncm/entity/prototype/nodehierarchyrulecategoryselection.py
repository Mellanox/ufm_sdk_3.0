from pythoncm.entity import NodeHierarchyRuleSelection


class NodeHierarchyRuleCategorySelection(NodeHierarchyRuleSelection):
    pass
