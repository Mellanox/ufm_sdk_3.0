from pythoncm.entity import MonitoringExecutionFilter


class MonitoringLuaExecutionFilter(MonitoringExecutionFilter):
    pass
