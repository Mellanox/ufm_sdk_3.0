from pythoncm.entity import Entity


class MonitoringPlotterSubSystemInfo(Entity):
    pass
