from pythoncm.entity import Entity


class FirewallZone(Entity):
    pass
