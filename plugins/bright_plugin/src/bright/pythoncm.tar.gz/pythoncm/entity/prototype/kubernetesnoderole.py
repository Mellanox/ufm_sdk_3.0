from pythoncm.entity import Role


class KubernetesNodeRole(Role):
    pass
