from pythoncm.entity import Entity


class FabricConfigurationBindingStatus(Entity):
    pass
