from pythoncm.entity import Entity


class MonitoringExecutionFilter(Entity):
    pass
