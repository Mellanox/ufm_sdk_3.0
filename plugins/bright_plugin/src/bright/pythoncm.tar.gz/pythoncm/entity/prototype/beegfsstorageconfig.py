from pythoncm.entity import Entity


class BeeGFSStorageConfig(Entity):
    pass
