from pythoncm.entity import Entity


class DiskVolume(Entity):
    pass
