from pythoncm.entity import Role


class KubernetesSchedulerRole(Role):
    pass
