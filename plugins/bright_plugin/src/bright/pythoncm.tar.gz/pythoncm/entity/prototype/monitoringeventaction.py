from pythoncm.entity import MonitoringAction


class MonitoringEventAction(MonitoringAction):
    pass
