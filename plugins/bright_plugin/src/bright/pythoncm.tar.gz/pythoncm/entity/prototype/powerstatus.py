from pythoncm.entity import Entity


class PowerStatus(Entity):
    pass
