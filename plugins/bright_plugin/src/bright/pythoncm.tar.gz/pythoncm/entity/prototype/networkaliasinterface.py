from pythoncm.entity import NetworkInterface


class NetworkAliasInterface(NetworkInterface):
    pass
