from pythoncm.entity import MonitoringPowerAction


class MonitoringPowerOnAction(MonitoringPowerAction):
    pass
