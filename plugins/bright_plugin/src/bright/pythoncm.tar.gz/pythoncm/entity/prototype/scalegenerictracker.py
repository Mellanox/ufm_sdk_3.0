from pythoncm.entity import ScaleTracker


class ScaleGenericTracker(ScaleTracker):
    pass
