from pythoncm.entity import Entity


class CMJobConfig(Entity):
    pass
