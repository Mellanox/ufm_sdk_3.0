from pythoncm.entity import Entity


class AzureDisk(Entity):
    pass
