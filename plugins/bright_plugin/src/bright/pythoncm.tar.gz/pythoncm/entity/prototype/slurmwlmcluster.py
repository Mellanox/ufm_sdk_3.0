from pythoncm.entity import WlmCluster


class SlurmWlmCluster(WlmCluster):
    pass
