from pythoncm.entity import Entity


class CustomizationFile(Entity):
    pass
