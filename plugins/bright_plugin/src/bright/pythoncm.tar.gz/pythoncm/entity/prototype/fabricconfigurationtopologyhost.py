from pythoncm.entity import FabricConfigurationTopologyDevice


class FabricConfigurationTopologyHost(FabricConfigurationTopologyDevice):
    pass
