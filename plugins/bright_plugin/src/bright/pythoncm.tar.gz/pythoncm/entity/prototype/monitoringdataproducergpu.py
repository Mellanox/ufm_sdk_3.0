from pythoncm.entity import MonitoringDataProducer


class MonitoringDataProducerGPU(MonitoringDataProducer):
    pass
