from pythoncm.entity import MonitoringExpression


class MonitoringGroupedExpression(MonitoringExpression):
    pass
