from pythoncm.entity import Entity


class BadEntityManagers(Entity):
    pass
