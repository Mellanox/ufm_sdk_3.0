from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerProcNetSnmp(MonitoringDataProducerInternal):
    pass
