from pythoncm.entity import Entity


class ResourcePool(Entity):
    pass
