from pythoncm.entity import Entity


class DiskPartition(Entity):
    pass
