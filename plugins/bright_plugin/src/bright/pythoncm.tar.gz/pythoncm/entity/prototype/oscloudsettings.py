from pythoncm.entity import CloudSettings


class OSCloudSettings(CloudSettings):
    pass
