from pythoncm.entity import Entity


class EC2RegionAMI(Entity):
    pass
