from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerProcNetDev(MonitoringDataProducerInternal):
    pass
