from pythoncm.entity import Entity


class FabricConfigurationBinding(Entity):
    pass
