from pythoncm.entity import PbsProRole


class PbsProClientRole(PbsProRole):
    pass
