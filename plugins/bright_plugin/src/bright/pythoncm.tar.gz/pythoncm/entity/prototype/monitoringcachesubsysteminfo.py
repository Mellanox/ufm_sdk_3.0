from pythoncm.entity import Entity


class MonitoringCacheSubSystemInfo(Entity):
    pass
