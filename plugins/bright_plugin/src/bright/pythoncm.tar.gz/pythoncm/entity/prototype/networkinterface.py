from pythoncm.entity import Entity


class NetworkInterface(Entity):
    pass
