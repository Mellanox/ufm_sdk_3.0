from pythoncm.entity import Entity


class User(Entity):
    pass
