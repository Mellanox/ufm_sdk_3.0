from pythoncm.entity import ScaleEngine


class ScaleHpcEngine(ScaleEngine):
    pass
