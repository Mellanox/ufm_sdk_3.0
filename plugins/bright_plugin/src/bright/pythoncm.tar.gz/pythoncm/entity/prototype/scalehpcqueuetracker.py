from pythoncm.entity import ScaleTracker


class ScaleHpcQueueTracker(ScaleTracker):
    pass
