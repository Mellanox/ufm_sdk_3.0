from pythoncm.entity import Entity


class BurnConfig(Entity):
    pass
