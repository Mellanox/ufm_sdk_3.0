from pythoncm.entity import Entity


class SoftwareImageRevisionInfo(Entity):
    pass
