from pythoncm.entity import GenericRoleConfiguration


class GenericRoleSymlinkConfiguration(GenericRoleConfiguration):
    pass
