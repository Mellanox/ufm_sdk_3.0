from pythoncm.entity import Entity


class ReportQuery(Entity):
    pass
