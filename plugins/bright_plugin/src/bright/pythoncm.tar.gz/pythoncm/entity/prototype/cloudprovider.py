from pythoncm.entity import Entity


class CloudProvider(Entity):
    pass
