from pythoncm.entity import Entity


class ProvisioningStatus(Entity):
    pass
