from pythoncm.entity import EC2Storage


class EC2EphemeralStorage(EC2Storage):
    pass
