from pythoncm.entity import Entity


class Network(Entity):
    pass
