from pythoncm.entity import NetworkInterface


class NetworkVLANInterface(NetworkInterface):
    pass
