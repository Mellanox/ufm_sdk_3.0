from pythoncm.entity import Role


class DockerHostRole(Role):
    pass
