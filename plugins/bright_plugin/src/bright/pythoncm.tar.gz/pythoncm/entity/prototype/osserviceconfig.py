from pythoncm.entity import Entity


class OSServiceConfig(Entity):
    pass
