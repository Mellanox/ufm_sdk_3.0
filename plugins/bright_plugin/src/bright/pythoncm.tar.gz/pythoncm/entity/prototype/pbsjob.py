from pythoncm.entity import Job


class PBSJob(Job):
    pass
