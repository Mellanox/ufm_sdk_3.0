from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerSysInfo(MonitoringDataProducerInternal):
    pass
