from pythoncm.entity import Entity


class EC2AvailabilityZone(Entity):
    pass
