from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerPowerDistributionUnit(MonitoringDataProducerInternal):
    pass
