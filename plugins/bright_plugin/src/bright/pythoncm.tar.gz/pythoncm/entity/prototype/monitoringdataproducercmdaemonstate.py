from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerCMDaemonState(MonitoringDataProducerInternal):
    pass
