from pythoncm.entity import Entity


class MonitoringExpression(Entity):
    pass
