from pythoncm.entity import Entity


class JupyterHubConfig(Entity):
    pass
