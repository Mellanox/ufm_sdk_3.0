from pythoncm.entity import MonitoringMeasurable


class MonitoringMeasurableEnum(MonitoringMeasurable):
    pass
