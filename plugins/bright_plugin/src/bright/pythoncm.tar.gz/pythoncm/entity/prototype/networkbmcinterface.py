from pythoncm.entity import NetworkInterface


class NetworkBmcInterface(NetworkInterface):
    pass
