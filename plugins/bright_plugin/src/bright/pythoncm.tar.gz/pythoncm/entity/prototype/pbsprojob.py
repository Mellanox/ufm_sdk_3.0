from pythoncm.entity import PBSJob


class PbsProJob(PBSJob):
    pass
