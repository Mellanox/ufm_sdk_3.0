from pythoncm.entity import ExternalOperationResult


class ExternalOperationRawResult(ExternalOperationResult):
    pass
