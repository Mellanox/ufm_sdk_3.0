from pythoncm.entity import Role


class KubernetesControllerRole(Role):
    pass
