from pythoncm.entity import FabricDevice


class FabricSwitch(FabricDevice):
    pass
