from pythoncm.entity import ScaleEngine


class ScaleGenericEngine(ScaleEngine):
    pass
