from pythoncm.entity import BaseNginxRole


class NginxRole(BaseNginxRole):
    pass
