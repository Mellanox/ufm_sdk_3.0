from pythoncm.entity import Entity


class ScalePendingWorkload(Entity):
    pass
