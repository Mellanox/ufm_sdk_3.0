from pythoncm.entity import Entity


class ArchOSInfo(Entity):
    pass
