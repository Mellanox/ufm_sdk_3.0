from pythoncm.entity import Entity


class FabricConfigurationTopologyZone(Entity):
    pass
