from pythoncm.entity import EC2Storage


class EC2EBSStorage(EC2Storage):
    pass
