from pythoncm.entity import Entity


class PowerOperationStatus(Entity):
    pass
