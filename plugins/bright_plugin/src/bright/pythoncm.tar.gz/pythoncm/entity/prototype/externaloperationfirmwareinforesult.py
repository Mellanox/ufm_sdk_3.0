from pythoncm.entity import ExternalOperationResult


class ExternalOperationFirmwareInfoResult(ExternalOperationResult):
    pass
