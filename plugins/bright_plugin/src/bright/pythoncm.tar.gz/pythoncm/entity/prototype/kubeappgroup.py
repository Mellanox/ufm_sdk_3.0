from pythoncm.entity import Entity


class KubeAppGroup(Entity):
    pass
