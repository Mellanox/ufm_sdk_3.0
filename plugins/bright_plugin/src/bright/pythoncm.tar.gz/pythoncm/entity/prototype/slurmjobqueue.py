from pythoncm.entity import JobQueue


class SlurmJobQueue(JobQueue):
    pass
