from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerAlertLevel(MonitoringDataProducerInternal):
    pass
