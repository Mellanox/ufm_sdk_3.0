from pythoncm.entity import SlurmRole


class SlurmClientRole(SlurmRole):
    pass
