from pythoncm.entity import Entity


class LabeledEntity(Entity):
    pass
