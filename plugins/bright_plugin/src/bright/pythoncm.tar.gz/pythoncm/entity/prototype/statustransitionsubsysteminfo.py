from pythoncm.entity import StatusSubSystemInfo


class StatusTransitionSubSystemInfo(StatusSubSystemInfo):
    pass
