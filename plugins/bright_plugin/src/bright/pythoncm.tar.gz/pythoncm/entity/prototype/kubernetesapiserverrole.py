from pythoncm.entity import Role


class KubernetesApiServerRole(Role):
    pass
