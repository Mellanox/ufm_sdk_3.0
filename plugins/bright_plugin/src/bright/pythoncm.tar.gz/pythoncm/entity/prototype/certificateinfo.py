from pythoncm.entity import Entity


class CertificateInfo(Entity):
    pass
