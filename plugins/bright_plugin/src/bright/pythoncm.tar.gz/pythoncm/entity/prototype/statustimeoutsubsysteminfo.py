from pythoncm.entity import StatusSubSystemInfo


class StatusTimeoutSubSystemInfo(StatusSubSystemInfo):
    pass
