from pythoncm.entity import Entity


class GuiKubeClusterOverview(Entity):
    pass
