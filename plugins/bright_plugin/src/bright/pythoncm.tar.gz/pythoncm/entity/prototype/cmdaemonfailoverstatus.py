from pythoncm.entity import Entity


class CMDaemonFailoverStatus(Entity):
    pass
