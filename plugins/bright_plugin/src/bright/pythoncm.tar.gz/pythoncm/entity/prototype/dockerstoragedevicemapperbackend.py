from pythoncm.entity import DockerStorageBackend


class DockerStorageDeviceMapperBackend(DockerStorageBackend):
    pass
