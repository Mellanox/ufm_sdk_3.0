from pythoncm.entity import Entity


class SoftwareImageProxy(Entity):
    pass
