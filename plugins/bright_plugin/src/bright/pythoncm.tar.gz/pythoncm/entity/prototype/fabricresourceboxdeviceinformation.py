from pythoncm.entity import Entity


class FabricResourceBoxDeviceInformation(Entity):
    pass
