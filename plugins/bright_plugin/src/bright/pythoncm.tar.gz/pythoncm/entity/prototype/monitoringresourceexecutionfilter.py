from pythoncm.entity import MonitoringExecutionFilter


class MonitoringResourceExecutionFilter(MonitoringExecutionFilter):
    pass
