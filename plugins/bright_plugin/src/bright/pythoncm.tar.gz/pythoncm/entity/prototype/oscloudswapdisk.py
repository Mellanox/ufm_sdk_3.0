from pythoncm.entity import OSCloudDisk


class OSCloudSwapDisk(OSCloudDisk):
    pass
