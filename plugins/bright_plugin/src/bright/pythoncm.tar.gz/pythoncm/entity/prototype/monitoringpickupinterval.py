from pythoncm.entity import Entity


class MonitoringPickupInterval(Entity):
    pass
