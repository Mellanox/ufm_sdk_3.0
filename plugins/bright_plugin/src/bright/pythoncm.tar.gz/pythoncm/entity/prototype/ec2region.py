from pythoncm.entity import CloudRegion


class EC2Region(CloudRegion):
    pass
