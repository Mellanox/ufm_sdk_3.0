from pythoncm.entity import MonitoringServiceAction


class MonitoringServiceRestartAction(MonitoringServiceAction):
    pass
