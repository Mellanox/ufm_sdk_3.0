from pythoncm.entity import Entity


class SlurmGenericResource(Entity):
    pass
