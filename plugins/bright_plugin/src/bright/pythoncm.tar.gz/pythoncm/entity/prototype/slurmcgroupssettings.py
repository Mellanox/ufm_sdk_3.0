from pythoncm.entity import WlmCgroupsSettings


class SlurmCgroupsSettings(WlmCgroupsSettings):
    pass
