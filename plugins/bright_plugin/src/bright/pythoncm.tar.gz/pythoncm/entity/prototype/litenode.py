from pythoncm.entity import Device


class LiteNode(Device):
    pass
