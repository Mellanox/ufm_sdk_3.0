from pythoncm.entity import Entity


class Process(Entity):
    pass
