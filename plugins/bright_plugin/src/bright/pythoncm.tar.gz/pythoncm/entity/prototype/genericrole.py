from pythoncm.entity import Role


class GenericRole(Role):
    pass
