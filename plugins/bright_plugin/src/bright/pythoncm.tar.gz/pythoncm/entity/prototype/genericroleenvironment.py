from pythoncm.entity import Entity


class GenericRoleEnvironment(Entity):
    pass
