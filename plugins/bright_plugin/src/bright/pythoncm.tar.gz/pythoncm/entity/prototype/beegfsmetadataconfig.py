from pythoncm.entity import Entity


class BeeGFSMetadataConfig(Entity):
    pass
