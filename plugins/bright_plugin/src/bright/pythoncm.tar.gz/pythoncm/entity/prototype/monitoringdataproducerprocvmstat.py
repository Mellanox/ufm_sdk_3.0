from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerProcVMStat(MonitoringDataProducerInternal):
    pass
