from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerProcPidStat(MonitoringDataProducerInternal):
    pass
