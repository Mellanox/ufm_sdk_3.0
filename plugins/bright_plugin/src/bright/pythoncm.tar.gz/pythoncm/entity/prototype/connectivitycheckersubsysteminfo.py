from pythoncm.entity import SubSystemInfo


class ConnectivityCheckerSubSystemInfo(SubSystemInfo):
    pass
