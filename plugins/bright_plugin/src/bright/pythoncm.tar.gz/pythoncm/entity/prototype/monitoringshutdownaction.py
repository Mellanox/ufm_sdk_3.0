from pythoncm.entity import MonitoringAction


class MonitoringShutdownAction(MonitoringAction):
    pass
