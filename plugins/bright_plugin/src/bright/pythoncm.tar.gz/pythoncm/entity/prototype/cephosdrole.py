from pythoncm.entity import Role


class CephOSDRole(Role):
    pass
