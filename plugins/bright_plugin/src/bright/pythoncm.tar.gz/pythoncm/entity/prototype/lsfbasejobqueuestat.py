from pythoncm.entity import JobQueueStat


class LSFBaseJobQueueStat(JobQueueStat):
    pass
