from pythoncm.entity import NetworkInterface


class NetworkBondInterface(NetworkInterface):
    pass
