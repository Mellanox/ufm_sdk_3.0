from pythoncm.entity import Entity


class Certificate(Entity):
    pass
