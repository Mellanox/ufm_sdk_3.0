from pythoncm.entity import Switch


class IBSwitch(Switch):
    pass
