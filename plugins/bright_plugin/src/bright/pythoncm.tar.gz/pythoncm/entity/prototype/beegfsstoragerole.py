from pythoncm.entity import Role


class BeeGFSStorageRole(Role):
    pass
