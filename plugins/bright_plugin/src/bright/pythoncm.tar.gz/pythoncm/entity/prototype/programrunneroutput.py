from pythoncm.entity import Entity


class ProgramRunnerOutput(Entity):
    pass
