from pythoncm.entity import MonitoringExecutionFilter


class MonitoringCategoryListExecutionFilter(MonitoringExecutionFilter):
    pass
