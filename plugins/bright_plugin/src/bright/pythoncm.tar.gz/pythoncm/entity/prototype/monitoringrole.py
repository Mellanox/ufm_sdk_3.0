from pythoncm.entity import Role


class MonitoringRole(Role):
    pass
