from pythoncm.entity import NodeHierarchyRuleSelection


class NodeHierarchyRuleDeviceSelection(NodeHierarchyRuleSelection):
    pass
