from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerDeviceState(MonitoringDataProducerInternal):
    pass
