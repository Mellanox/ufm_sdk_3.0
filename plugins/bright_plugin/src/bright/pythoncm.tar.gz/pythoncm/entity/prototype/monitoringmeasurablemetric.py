from pythoncm.entity import MonitoringMeasurable


class MonitoringMeasurableMetric(MonitoringMeasurable):
    pass
