from pythoncm.entity import Entity


class MonitoringServiceSubSystemInfo(Entity):
    pass
