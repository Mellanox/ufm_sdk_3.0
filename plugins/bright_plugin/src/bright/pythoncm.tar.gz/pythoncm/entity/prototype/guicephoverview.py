from pythoncm.entity import Entity


class GuiCephOverview(Entity):
    pass
