from pythoncm.entity import Entity


class BMCSettings(Entity):
    pass
