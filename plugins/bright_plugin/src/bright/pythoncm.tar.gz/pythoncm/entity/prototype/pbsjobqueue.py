from pythoncm.entity import JobQueue


class PBSJobQueue(JobQueue):
    pass
