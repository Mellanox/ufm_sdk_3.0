from pythoncm.entity import Entity


class WlmNodeResource(Entity):
    pass
