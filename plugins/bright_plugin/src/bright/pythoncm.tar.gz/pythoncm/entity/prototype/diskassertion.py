from pythoncm.entity import Entity


class DiskAssertion(Entity):
    pass
