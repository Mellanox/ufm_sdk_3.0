from pythoncm.entity import Entity


class KubeNodeLoad(Entity):
    pass
