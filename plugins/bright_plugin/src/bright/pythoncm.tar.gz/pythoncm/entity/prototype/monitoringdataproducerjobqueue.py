from pythoncm.entity import MonitoringDataProducer


class MonitoringDataProducerJobQueue(MonitoringDataProducer):
    pass
