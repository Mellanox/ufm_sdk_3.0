from pythoncm.entity import Entity


class GuiDiskUsage(Entity):
    pass
