from pythoncm.entity import StatusSubSystemInfo


class StatusRuleSubSystemInfo(StatusSubSystemInfo):
    pass
