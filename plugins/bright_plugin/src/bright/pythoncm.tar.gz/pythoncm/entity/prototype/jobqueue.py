from pythoncm.entity import Entity


class JobQueue(Entity):
    pass
