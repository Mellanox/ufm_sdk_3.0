from pythoncm.entity import OpenShiftRole


class OpenShiftClientRole(OpenShiftRole):
    pass
