from pythoncm.entity import Entity


class ProgramRunnerStatus(Entity):
    pass
