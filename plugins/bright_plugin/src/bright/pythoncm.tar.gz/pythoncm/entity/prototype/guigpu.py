from pythoncm.entity import Entity


class GuiGPU(Entity):
    pass
