from pythoncm.entity import Entity


class FabricNodeStatus(Entity):
    pass
