from pythoncm.entity import Entity


class MonitoringConsolidator(Entity):
    pass
