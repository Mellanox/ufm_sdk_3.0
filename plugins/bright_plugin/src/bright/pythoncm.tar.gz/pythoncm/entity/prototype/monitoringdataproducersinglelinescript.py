from pythoncm.entity import MonitoringDataProducer


class MonitoringDataProducerSingleLineScript(MonitoringDataProducer):
    pass
