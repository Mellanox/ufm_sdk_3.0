from pythoncm.entity import Entity


class PrometheusRecordingRule(Entity):
    pass
