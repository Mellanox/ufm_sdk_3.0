from pythoncm.entity import Entity


class CMDaemonStatus(Entity):
    pass
