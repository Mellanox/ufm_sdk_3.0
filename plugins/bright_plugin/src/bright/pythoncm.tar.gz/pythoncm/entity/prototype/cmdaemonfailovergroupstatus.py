from pythoncm.entity import Entity


class CMDaemonFailoverGroupStatus(Entity):
    pass
