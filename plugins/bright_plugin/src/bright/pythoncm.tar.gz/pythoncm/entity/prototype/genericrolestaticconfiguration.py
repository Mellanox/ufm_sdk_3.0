from pythoncm.entity import GenericRoleConfiguration


class GenericRoleStaticConfiguration(GenericRoleConfiguration):
    pass
