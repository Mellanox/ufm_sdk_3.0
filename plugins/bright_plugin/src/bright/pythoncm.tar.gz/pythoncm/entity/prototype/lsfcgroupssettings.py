from pythoncm.entity import WlmCgroupsSettings


class LSFCgroupsSettings(WlmCgroupsSettings):
    pass
