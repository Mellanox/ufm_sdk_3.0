from pythoncm.entity import Entity


class Job(Entity):
    pass
