from pythoncm.entity import ExternalOperationResult


class ExternalOperationJSONResult(ExternalOperationResult):
    pass
