from pythoncm.entity import Entity


class MonitoringMeasurable(Entity):
    pass
