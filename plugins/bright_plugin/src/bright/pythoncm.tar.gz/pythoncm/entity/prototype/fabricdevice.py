from pythoncm.entity import Device


class FabricDevice(Device):
    pass
