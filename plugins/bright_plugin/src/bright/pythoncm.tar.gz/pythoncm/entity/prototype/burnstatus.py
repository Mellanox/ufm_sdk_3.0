from pythoncm.entity import Entity


class BurnStatus(Entity):
    pass
