from pythoncm.entity import MonitoringDataProducerInternal


class MonitoringDataProducerEC2SpotPrices(MonitoringDataProducerInternal):
    pass
