from pythoncm.entity import Entity


class GridEngineParallelEnvironment(Entity):
    pass
