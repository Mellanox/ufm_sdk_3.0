from pythoncm.entity import Entity


class PreJobResult(Entity):
    pass
