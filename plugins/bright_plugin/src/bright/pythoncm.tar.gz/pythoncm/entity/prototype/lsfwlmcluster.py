from pythoncm.entity import WlmCluster


class LSFWlmCluster(WlmCluster):
    pass
