from pythoncm.entity import Job


class LSFBaseJob(Job):
    pass
