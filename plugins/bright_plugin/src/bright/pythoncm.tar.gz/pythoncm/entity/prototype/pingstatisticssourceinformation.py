from pythoncm.entity import Entity


class PingStatisticsSourceInformation(Entity):
    pass
