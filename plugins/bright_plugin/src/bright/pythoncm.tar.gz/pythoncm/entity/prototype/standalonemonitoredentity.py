from pythoncm.entity import Entity


class StandaloneMonitoredEntity(Entity):
    pass
