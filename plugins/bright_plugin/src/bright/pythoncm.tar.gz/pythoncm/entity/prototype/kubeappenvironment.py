from pythoncm.entity import Entity


class KubeAppEnvironment(Entity):
    pass
