from pythoncm.entity import MonitoringAction


class MonitoringRebootAction(MonitoringAction):
    pass
