from pythoncm.entity import MonitoringDataProducer


class MonitoringDataProducerRecorder(MonitoringDataProducer):
    pass
