from pythoncm.entity import Entity


class EntityManagersMD5(Entity):
    pass
