from pythoncm.entity import Entity


class Ceph(Entity):
    pass
