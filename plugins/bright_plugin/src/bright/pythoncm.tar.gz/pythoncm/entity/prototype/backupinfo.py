from pythoncm.entity import Entity


class BackupInfo(Entity):
    pass
