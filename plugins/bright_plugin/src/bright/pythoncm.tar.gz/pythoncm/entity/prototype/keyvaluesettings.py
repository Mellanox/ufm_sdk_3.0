from pythoncm.entity import Entity


class KeyValueSettings(Entity):
    pass
