from pythoncm.entity import SubSystemInfo


class StatusSubSystemInfo(SubSystemInfo):
    pass
