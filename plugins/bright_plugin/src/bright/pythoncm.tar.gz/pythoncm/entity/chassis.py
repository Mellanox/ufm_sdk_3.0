#
# SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

from __future__ import annotations

import typing

from pythoncm.entity.device import Device

if typing.TYPE_CHECKING:
    from pythoncm.entity.network import Network


class Chassis(Device):
    @property
    def networks(self) -> list[Network]:
        """
        Get all networks on which the chassis is connected
        """
        if self.network:
            return [self.network]
        return []

    @property
    def network_ips(self) -> list[(Network, str)]:
        """
        Get all networks on which the chassis is connected
        """
        if self.network:
            return [(self.network, self.ip)]
        return []
